const { contextBridge, ipcRenderer } = require('electron');
const ALLOWED = new Set(['detect', 'stream:start', 'stream:stop', 'shot', 'wifi:enable', 'wifi:connect',
  'wifi:pair', 'wifi:disconnect', 'driver:fix', 'oem:open', 'apple:driver', 'apple:airplay', 'folder:open', 'adb:restart']);
contextBridge.exposeInMainWorld('api', {
  call: (ch, ...args) => ALLOWED.has(ch) ? ipcRenderer.invoke(ch, ...args) : Promise.resolve({ ok: false }),
  onEnded: (cb) => ipcRenderer.on('stream:ended', (_e, d) => cb(d))
});
