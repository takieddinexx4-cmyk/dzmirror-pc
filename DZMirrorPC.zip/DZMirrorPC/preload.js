const { contextBridge, ipcRenderer } = require('electron');

const ALLOWED = new Set([
  'detect',
  'adb:restart',
  'stream:start',
  'stream:stop',
  'stream:apply',
  'record:start',
  'record:stop',
  'recordings:list',
  'file:open',
  'file:reveal',
  'shot',
  'wifi:enable',
  'wifi:connect',
  'wifi:pair',
  'wifi:disconnect',
  'driver:fix',
  'oem:open',
  'apple:env',
  'apple:driver',
  'apple:bonjour',
  'apple:firewall',
  'apple:airplay:start',
  'apple:airplay:stop',
  'apple:airplay:status',
  'apple:airplay:pick',
  'keymap:load',
  'keymap:save',
  'keymap:overlay:open',
  'keymap:overlay:close',
  'keymap:overlay:mode',
  'keymap:overlay:config',
  'keymap:overlay:visibility',
  'folder:open',
  'sys:health',
  'sys:ips'
]);

contextBridge.exposeInMainWorld('api', {
  call: (ch, ...args) => (ALLOWED.has(ch) ? ipcRenderer.invoke(ch, ...args) : Promise.resolve({ ok: false, msg: 'Channel not allowed' })),
  onEnded: (cb) => ipcRenderer.on('stream:ended', (_e, d) => cb(d)),
  onStreamState: (cb) => ipcRenderer.on('stream:state', (_e, d) => cb(d)),
  onAirplayState: (cb) => ipcRenderer.on('airplay:state', (_e, d) => cb(d)),
  onKeymapEvent: (cb) => ipcRenderer.on('keymap:event', (_e, d) => cb(d)),
  onOverlayData: (cb) => ipcRenderer.on('overlay:data', (_e, d) => cb(d))
});
