const { app, BrowserWindow, ipcMain, shell } = require('electron');
const path = require('path');
const fs = require('fs');
const { spawn, spawnSync, execFile } = require('child_process');

const BIN = app.isPackaged ? path.join(process.resourcesPath, 'bin') : path.join(__dirname, 'bin');
const ADB = path.join(BIN, 'adb.exe');
const SCRCPY = path.join(BIN, 'scrcpy.exe');
const sessions = new Map();
let win = null;

const VENDORS = {
  '04E8': 'Samsung', '2717': 'Xiaomi', '18D1': 'Google', '12D1': 'Huawei', '22D9': 'OPPO', '2A70': 'OnePlus',
  '0BB4': 'HTC', '22B8': 'Motorola', '1004': 'LG', '0FCE': 'Sony', '2D95': 'vivo', '2A45': 'Meizu',
  '0E8D': 'MediaTek (Infinix/Tecno/realme)', '1782': 'Unisoc', '05C6': 'Qualcomm', '19D2': 'ZTE',
  '0B05': 'ASUS', '17EF': 'Lenovo', '1949': 'Amazon', '1BBB': 'Alcatel/TCL'
};

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const stamp = () => new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);

function run(cmd, args, timeout = 15000) {
  return new Promise((res) => {
    execFile(cmd, args, { windowsHide: true, timeout, maxBuffer: 20 * 1024 * 1024, env: { ...process.env, ADB } },
      (err, so, se) => res({ ok: !err, out: String(so || '').trim(), err: String(se || '').trim() }));
  });
}
const adb = (args, t) => run(ADB, args, t);
const ps = (script, t) => run('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', script], t || 20000);

async function deviceInfo(serial) {
  const cmd = 'getprop ro.product.manufacturer; getprop ro.product.model; getprop ro.product.marketname; ' +
    'getprop ro.build.version.release; getprop ro.build.version.sdk; dumpsys battery | grep level; wm size';
  const r = await adb(['-s', serial, 'shell', cmd], 8000);
  const L = r.out.split(/\r?\n/).map((s) => s.trim());
  const brandRaw = L[0] || 'Android';
  const brand = brandRaw.charAt(0).toUpperCase() + brandRaw.slice(1);
  const model = L[2] || L[1] || serial;
  const name = model.toLowerCase().startsWith(brand.toLowerCase()) ? model : `${brand} ${model}`;
  return {
    name, model: L[1] || '', brand, android: L[3] || '?', sdk: parseInt(L[4], 10) || 0,
    battery: (/level:\s*(\d+)/.exec(r.out) || [])[1] || null,
    size: (/size:\s*(\d+x\d+)/.exec(r.out) || [])[1] || null
  };
}

async function listDevices() {
  const r = await adb(['devices', '-l']);
  const lines = r.out.split(/\r?\n/).slice(1).filter((l) => l.trim() && !l.startsWith('*'));
  const devs = [];
  for (const l of lines) {
    const p = l.trim().split(/\s+/);
    const d = { serial: p[0], state: p[1], wifi: p[0].includes(':') || p[0].startsWith('adb-'), info: null };
    if (d.state === 'device') d.info = await deviceInfo(d.serial);
    devs.push(d);
  }
  return devs;
}

let usbCache = { t: 0, data: [] };
async function scanUsb() {
  if (Date.now() - usbCache.t < 6000) return usbCache.data;
  const script = "Get-PnpDevice -PresentOnly | Where-Object { $_.InstanceId -match '^USB\\\\VID_' } | " +
    'Select-Object FriendlyName,Class,Status,InstanceId | ConvertTo-Json -Compress';
  const r = await ps(script);
  let arr = [];
  try { const j = JSON.parse(r.out); arr = Array.isArray(j) ? j : [j]; } catch (e) { arr = []; }
  const vidOf = (d) => ((/VID_([0-9A-F]{4})/i.exec(d.InstanceId || '') || [])[1] || '').toUpperCase();
  const out = [];
  const seen = new Set();
  for (const d of arr) {
    if (/&MI_/i.test(d.InstanceId || '')) continue;
    const vid = vidOf(d);
    const nameHit = /android|phone|adb|mtp|iphone|ipad/i.test(d.FriendlyName || '');
    if (!VENDORS[vid] && vid !== '05AC' && !nameHit) continue;
    if (/hub|host controller/i.test(d.FriendlyName || '')) continue;
    const key = d.InstanceId;
    if (seen.has(key)) continue;
    seen.add(key);
    out.push({
      vid, kind: vid === '05AC' ? 'ios' : 'android', vendor: VENDORS[vid] || 'Android',
      name: d.FriendlyName || '', issue: arr.some((x) => vidOf(x) === vid && x.Status && x.Status !== 'OK')
    });
  }
  usbCache = { t: Date.now(), data: out };
  return out;
}

async function detect() {
  const [devices, usb] = await Promise.all([listDevices(), scanUsb()]);
  let appleDriver = true;
  if (usb.some((u) => u.kind === 'ios')) appleDriver = (await run('sc.exe', ['query', 'AppleMobileDeviceService'])).ok;
  return { ok: true, devices, usb, appleDriver, active: [...sessions.keys()] };
}

function findInf(dir) {
  try {
    for (const f of fs.readdirSync(dir, { withFileTypes: true })) {
      const p = path.join(dir, f.name);
      if (f.isDirectory()) { const r = findInf(p); if (r) return r; }
      else if (f.name.toLowerCase() === 'android_winusb.inf') return p;
    }
  } catch (e) { /* ignore */ }
  return null;
}

function createWindow() {
  const icon = path.join(__dirname, 'build', 'icon.png');
  win = new BrowserWindow({
    width: 1120, height: 740, minWidth: 920, minHeight: 620, backgroundColor: '#07100b', title: 'DZ Mirror',
    icon: fs.existsSync(icon) ? icon : undefined,
    titleBarStyle: 'hidden', titleBarOverlay: { color: '#07100b', symbolColor: '#e8f5ee', height: 38 },
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false }
  });
  win.setMenuBarVisibility(false);
  win.loadFile(path.join(__dirname, 'renderer', 'index.html'));
}

if (!app.requestSingleInstanceLock()) app.quit();
app.whenReady().then(() => { adb(['start-server'], 20000); createWindow(); });
app.on('window-all-closed', () => app.quit());
app.on('will-quit', () => {
  for (const c of sessions.values()) { try { c.kill(); } catch (e) { /* ignore */ } }
  try { spawnSync(ADB, ['kill-server'], { windowsHide: true, timeout: 5000 }); } catch (e) { /* ignore */ }
});

ipcMain.handle('detect', () => detect());
ipcMain.handle('adb:restart', async () => { await adb(['kill-server']); await adb(['start-server'], 20000); usbCache.t = 0; return { ok: true }; });

ipcMain.handle('stream:start', (_e, serial, o) => {
  if (sessions.has(serial)) return { ok: false, msg: 'البث يعمل بالفعل' };
  if (!fs.existsSync(SCRCPY)) return { ok: false, msg: 'محرك البث غير موجود في هذه النسخة' };
  const a = ['-s', serial, `--window-title=DZ Mirror - ${o.title || serial}`,
    `--max-fps=${o.fps}`, `--video-bit-rate=${o.bitrate}M`, `--video-codec=${o.codec}`,
    o.mode === 'fast' ? '--video-buffer=0' : '--video-buffer=60'];
  if (o.maxSize) a.push(`--max-size=${o.maxSize}`);
  if (o.audio && o.sdk >= 30) a.push(o.mode === 'fast' ? '--audio-buffer=40' : '--audio-buffer=100');
  else a.push('--no-audio');
  if (o.awake) a.push('--stay-awake');
  if (o.off) a.push('--turn-screen-off');
  if (o.touch) a.push('--show-touches');
  if (o.top) a.push('--always-on-top');
  if (o.view) a.push('--no-control');
  if (o.rec) {
    const dir = path.join(app.getPath('videos'), 'DZMirror');
    fs.mkdirSync(dir, { recursive: true });
    a.push(`--record=${path.join(dir, `${(o.title || 'phone').replace(/[^\w.-]+/g, '_')}-${stamp()}.mp4`)}`);
  }
  const log = [];
  const c = spawn(SCRCPY, a, { windowsHide: true, env: { ...process.env, ADB } });
  const grab = (b) => { log.push(...String(b).split(/\r?\n/).filter(Boolean)); if (log.length > 30) log.splice(0, log.length - 30); };
  c.stdout.on('data', grab);
  c.stderr.on('data', grab);
  c.on('error', (err) => { sessions.delete(serial); win && win.webContents.send('stream:ended', { serial, code: -1, msg: String(err) }); });
  c.on('exit', (code) => {
    sessions.delete(serial);
    const bad = log.filter((l) => /ERROR/i.test(l)).slice(-2).join(' | ');
    win && !win.isDestroyed() && win.webContents.send('stream:ended', { serial, code, msg: code ? bad : '' });
  });
  sessions.set(serial, c);
  return { ok: true };
});

ipcMain.handle('stream:stop', (_e, serial) => { const c = sessions.get(serial); if (c) c.kill(); return { ok: true }; });

ipcMain.handle('shot', (_e, serial, name) => new Promise((res) => {
  const dir = path.join(app.getPath('pictures'), 'DZMirror');
  fs.mkdirSync(dir, { recursive: true });
  const file = path.join(dir, `${(name || 'phone').replace(/[^\w.-]+/g, '_')}-${stamp()}.png`);
  const p = spawn(ADB, ['-s', serial, 'exec-out', 'screencap', '-p'], { windowsHide: true });
  const ws = fs.createWriteStream(file);
  p.stdout.pipe(ws);
  ws.on('finish', () => res({ ok: fs.statSync(file).size > 1000, file }));
  p.on('error', () => res({ ok: false }));
}));

ipcMain.handle('wifi:enable', async (_e, serial) => {
  const r = await adb(['-s', serial, 'shell', 'ip', '-f', 'inet', 'addr', 'show', 'wlan0']);
  const m = /inet (\d+\.\d+\.\d+\.\d+)/.exec(r.out);
  if (!m) return { ok: false, msg: 'تعذّر معرفة عنوان الواي فاي، تأكد أن الهاتف متصل بالشبكة' };
  await adb(['-s', serial, 'tcpip', '5555']);
  await sleep(1800);
  const c = await adb(['connect', `${m[1]}:5555`]);
  return { ok: /connected/i.test(c.out), msg: c.out || c.err, ip: m[1] };
});
ipcMain.handle('wifi:connect', async (_e, host) => {
  const h = String(host || '').trim();
  if (!/^[\w.\-]+(:\d+)?$/.test(h)) return { ok: false, msg: 'عنوان غير صحيح' };
  const c = await adb(['connect', h.includes(':') ? h : `${h}:5555`], 20000);
  return { ok: /connected/i.test(c.out) && !/cannot|failed/i.test(c.out), msg: c.out || c.err };
});
ipcMain.handle('wifi:pair', async (_e, host, code) => {
  if (!/^[\w.\-]+:\d+$/.test(String(host || '').trim()) || !/^\d{6}$/.test(String(code || '').trim()))
    return { ok: false, msg: 'أدخل العنوان مع المنفذ (مثل 192.168.1.5:37123) والرمز المكوّن من 6 أرقام' };
  const r = await adb(['pair', host.trim(), code.trim()], 25000);
  return { ok: /success/i.test(r.out), msg: r.out || r.err };
});
ipcMain.handle('wifi:disconnect', async (_e, serial) => { await adb(['disconnect', serial]); return { ok: true }; });

ipcMain.handle('driver:fix', async () => {
  const inf = findInf(path.join(BIN, 'driver'));
  if (!inf) return { ok: false, msg: 'حزمة التعريفات غير مضمّنة، استخدم زر موقع الشركة المصنّعة' };
  const safe = inf.replace(/'/g, "''");
  const r = await ps(`Start-Process -FilePath pnputil.exe -ArgumentList '/add-driver "${safe}" /install' -Verb RunAs -Wait`, 120000);
  await run('pnputil.exe', ['/scan-devices']);
  await adb(['kill-server']); await adb(['start-server'], 20000);
  usbCache.t = 0;
  return { ok: r.ok, msg: r.ok ? 'تم تثبيت التعريفات. افصل الهاتف وأعد توصيله' : 'أُلغي التثبيت أو لم تُمنح صلاحية المسؤول' };
});
ipcMain.handle('oem:open', (_e, vendor) => {
  const q = encodeURIComponent(`${String(vendor).split(' ')[0]} USB driver Windows`);
  shell.openExternal(`https://www.google.com/search?q=${q}`);
  return { ok: true };
});
ipcMain.handle('apple:driver', () => { shell.openExternal('ms-windows-store://pdp/?productid=9NP83LWLZM3F'); return { ok: true }; });
ipcMain.handle('apple:airplay', () => {
  const ux = path.join(BIN, 'uxplay', 'uxplay.exe');
  if (!fs.existsSync(ux)) return { ok: false, msg: 'مستقبِل AirPlay غير مضمّن في هذا الإصدار، سيُضاف في التحديث القادم' };
  spawn(ux, ['-n', 'DZ Mirror'], { windowsHide: true, detached: true, stdio: 'ignore' }).unref();
  return { ok: true, msg: 'على الآيفون: مركز التحكم ← مشاركة الشاشة ← DZ Mirror' };
});
ipcMain.handle('folder:open', (_e, kind) => {
  const dir = path.join(app.getPath(kind === 'video' ? 'videos' : 'pictures'), 'DZMirror');
  fs.mkdirSync(dir, { recursive: true });
  shell.openPath(dir);
  return { ok: true };
});
