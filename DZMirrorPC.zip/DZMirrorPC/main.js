const { app, BrowserWindow, ipcMain, shell, dialog, screen } = require('electron');
const path = require('path');
const fs = require('fs');
const os = require('os');
const { spawn, spawnSync, execFile } = require('child_process');

const BIN = app.isPackaged ? path.join(process.resourcesPath, 'bin') : path.join(__dirname, 'bin');
const HELPERS = path.join(__dirname, 'helpers');
const ADB = path.join(BIN, 'adb.exe');
const SCRCPY = path.join(BIN, 'scrcpy.exe');

// Active scrcpy sessions: serial -> { proc, opts, title, sdk, windowTitle, recording, recFile, recStart, recOpts }
const sessions = new Map();
const restarting = new Set();

// Device info cache to avoid running shell getprop every polling tick
const deviceInfoCache = new Map();

// AirPlay process state
let airplay = {
  proc: null,
  running: false,
  connected: false,
  name: 'DZ Mirror',
  resolution: '1920x1080',
  fps: 60,
  audio: true,
  customPath: '',
  logs: []
};

// Keymap overlay state
let overlayWin = null;
let bridgeProc = null;
let overlayTargetSerial = null;
let overlayConfig = {
  enabled: true,
  editMode: false,
  visible: true,
  opacity: 0.72,
  activeProfileId: 'pubg',
  buttons: []
};

let win = null;

const VENDORS = {
  '04E8': 'Samsung', '2717': 'Xiaomi', '18D1': 'Google', '12D1': 'Huawei', '22D9': 'OPPO', '2A70': 'OnePlus',
  '0BB4': 'HTC', '22B8': 'Motorola', '1004': 'LG', '0FCE': 'Sony', '2D95': 'vivo', '2A45': 'Meizu',
  '0E8D': 'MediaTek (Infinix/Tecno/realme)', '1782': 'Unisoc', '05C6': 'Qualcomm', '19D2': 'ZTE',
  '0B05': 'ASUS', '17EF': 'Lenovo', '1949': 'Amazon', '1BBB': 'Alcatel/TCL', '05AC': 'Apple'
};

const DEFAULT_KEYMAPS = {
  activeProfileId: 'pubg',
  opacity: 0.72,
  visible: true,
  enabled: true,
  profiles: [
    {
      id: 'pubg',
      name: 'PUBG Mobile',
      buttons: [
        { id: 'joy1', type: 'joystick', label: 'حركة', up: 'W', down: 'S', left: 'A', right: 'D', x: 17, y: 74, radius: 11 },
        { id: 'fire', type: 'tap', label: 'إطلاق', key: 'F', x: 86, y: 72, size: 54 },
        { id: 'scope', type: 'tap', label: 'تصويب', key: 'Q', x: 91, y: 51, size: 46 },
        { id: 'jump', type: 'tap', label: 'قفز', key: 'SPACE', x: 91, y: 84, size: 46 },
        { id: 'crouch', type: 'tap', label: 'انحناء', key: 'C', x: 80, y: 88, size: 44 },
        { id: 'prone', type: 'tap', label: 'انبطاح', key: 'Z', x: 72, y: 88, size: 44 },
        { id: 'reload', type: 'tap', label: 'تعبئة', key: 'R', x: 74, y: 73, size: 44 },
        { id: 'peekL', type: 'tap', label: 'ميل', key: 'E', x: 24, y: 38, size: 40 },
        { id: 'wep1', type: 'tap', label: 'سلاح 1', key: '1', x: 43, y: 89, size: 42 },
        { id: 'wep2', type: 'tap', label: 'سلاح 2', key: '2', x: 56, y: 89, size: 42 },
        { id: 'bag', type: 'tap', label: 'حقيبة', key: 'TAB', x: 11, y: 88, size: 42 },
        { id: 'map', type: 'tap', label: 'خريطة', key: 'M', x: 92, y: 14, size: 40 }
      ]
    },
    {
      id: 'freefire',
      name: 'Free Fire',
      buttons: [
        { id: 'joy1', type: 'joystick', label: 'حركة', up: 'W', down: 'S', left: 'A', right: 'D', x: 16, y: 76, radius: 11 },
        { id: 'fire', type: 'tap', label: 'إطلاق', key: 'F', x: 87, y: 74, size: 54 },
        { id: 'scope', type: 'tap', label: 'تصويب', key: 'Q', x: 92, y: 48, size: 46 },
        { id: 'jump', type: 'tap', label: 'قفز', key: 'SPACE', x: 92, y: 63, size: 46 },
        { id: 'crouch', type: 'tap', label: 'انحناء', key: 'C', x: 83, y: 89, size: 44 },
        { id: 'gloo', type: 'tap', label: 'ثلج', key: 'G', x: 27, y: 86, size: 44 },
        { id: 'med', type: 'tap', label: 'علاج', key: '4', x: 10, y: 58, size: 42 },
        { id: 'reload', type: 'tap', label: 'تعبئة', key: 'R', x: 86, y: 17, size: 44 }
      ]
    },
    {
      id: 'codm',
      name: 'Call of Duty Mobile',
      buttons: [
        { id: 'joy1', type: 'joystick', label: 'حركة', up: 'W', down: 'S', left: 'A', right: 'D', x: 17, y: 74, radius: 11 },
        { id: 'fire', type: 'tap', label: 'إطلاق', key: 'F', x: 86, y: 72, size: 54 },
        { id: 'ads', type: 'tap', label: 'منظار', key: 'Q', x: 91, y: 50, size: 46 },
        { id: 'jump', type: 'tap', label: 'قفز', key: 'SPACE', x: 91, y: 84, size: 46 },
        { id: 'slide', type: 'tap', label: 'انزلاق', key: 'C', x: 81, y: 88, size: 44 },
        { id: 'reload', type: 'tap', label: 'تعبئة', key: 'R', x: 74, y: 75, size: 44 },
        { id: 'nade', type: 'tap', label: 'قنبلة', key: 'G', x: 66, y: 86, size: 42 }
      ]
    }
  ]
};

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const stamp = () => new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);

function sendMain(ch, payload) {
  if (win && !win.isDestroyed()) win.webContents.send(ch, payload);
}
function sendOverlay(ch, payload) {
  if (overlayWin && !overlayWin.isDestroyed()) overlayWin.webContents.send(ch, payload);
}

function run(cmd, args, timeout = 12000) {
  return new Promise((res) => {
    execFile(
      cmd,
      args,
      { windowsHide: true, timeout, maxBuffer: 20 * 1024 * 1024, env: { ...process.env, ADB } },
      (err, so, se) => res({ ok: !err, code: err ? err.code : 0, out: String(so || '').trim(), err: String(se || '').trim() })
    );
  });
}

const adb = (args, t) => run(ADB, args, t);
const ps = (script, t) => run('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', script], t || 15000);

function getLocalIPs() {
  const nets = os.networkInterfaces();
  const ips = [];
  for (const name of Object.keys(nets)) {
    for (const net of nets[name] || []) {
      if (net.family === 'IPv4' && !net.internal) {
        ips.push({ iface: name, address: net.address });
      }
    }
  }
  return ips;
}

// ---------- Fast Cached Android Device Discovery ----------
async function deviceInfo(serial) {
  const cached = deviceInfoCache.get(serial);
  if (cached && Date.now() - cached.ts < 25000) {
    return cached.data;
  }
  const cmd =
    'getprop ro.product.manufacturer; getprop ro.product.model; getprop ro.product.marketname; ' +
    'getprop ro.build.version.release; getprop ro.build.version.sdk; dumpsys battery | grep level; wm size';
  const r = await adb(['-s', serial, 'shell', cmd], 6000);
  const L = r.out.split(/\r?\n/).map((s) => s.trim());
  const brandRaw = L[0] || 'Android';
  const brand = brandRaw.charAt(0).toUpperCase() + brandRaw.slice(1);
  const model = L[2] || L[1] || serial;
  const name = model.toLowerCase().startsWith(brand.toLowerCase()) ? model : `${brand} ${model}`;
  const info = {
    name,
    model: L[1] || '',
    brand,
    android: L[3] || '?',
    sdk: parseInt(L[4], 10) || 0,
    battery: (/level:\s*(\d+)/.exec(r.out) || [])[1] || null,
    size: (/size:\s*(\d+x\d+)/.exec(r.out) || [])[1] || null
  };
  deviceInfoCache.set(serial, { ts: Date.now(), data: info });
  return info;
}

async function listDevices() {
  if (!fs.existsSync(ADB)) return [];
  const r = await adb(['devices', '-l'], 5000);
  const lines = r.out.split(/\r?\n/).slice(1).filter((l) => l.trim() && !l.startsWith('*'));
  const devs = [];
  const activeSerials = new Set();

  for (const l of lines) {
    const p = l.trim().split(/\s+/);
    const serial = p[0];
    const state = p[1];
    activeSerials.add(serial);
    const d = { serial, state, wifi: serial.includes(':') || serial.startsWith('adb-'), info: null };
    if (state === 'device') d.info = await deviceInfo(serial);
    devs.push(d);
  }

  for (const k of deviceInfoCache.keys()) {
    if (!activeSerials.has(k)) deviceInfoCache.delete(k);
  }
  return devs;
}

// ---------- Non-blocking Background USB & Apple Environment Scanner ----------
let usbCache = { t: 0, data: [], pending: null };
async function scanUsb(force = false) {
  if (!force && Date.now() - usbCache.t < 15000) return usbCache.data;
  if (usbCache.pending) return usbCache.pending;

  usbCache.pending = (async () => {
    const script =
      "Get-PnpDevice -PresentOnly | Where-Object { $_.InstanceId -match 'VID_([0-9A-F]{4})' -or $_.FriendlyName -match 'iPhone|iPad|Apple Mobile Device' } | " +
      'Select-Object FriendlyName,Class,Status,InstanceId | ConvertTo-Json -Compress';
    const r = await ps(script, 10000);
    let arr = [];
    try {
      const j = JSON.parse(r.out);
      arr = Array.isArray(j) ? j : j ? [j] : [];
    } catch (e) {
      arr = [];
    }
    const vidOf = (d) => ((/VID_([0-9A-F]{4})/i.exec(d.InstanceId || '') || [])[1] || '').toUpperCase();
    const out = [];
    const seen = new Set();

    for (const d of arr) {
      const inst = d.InstanceId || '';
      const fname = d.FriendlyName || '';
      const vid = vidOf(d);
      const isApple = vid === '05AC' || /iphone|ipad|apple mobile device/i.test(fname);

      if (!isApple && /&MI_/i.test(inst)) continue;
      const nameHit = /android|phone|adb|mtp|iphone|ipad|apple mobile/i.test(fname);
      if (!VENDORS[vid] && !isApple && !nameHit) continue;
      if (/hub|host controller|root hub|camera|audio endpoint/i.test(fname)) continue;

      const dedupKey = isApple ? `APPLE_${(inst.split('\\')[2] || fname).split('&')[0]}` : inst;
      if (seen.has(dedupKey)) continue;
      seen.add(dedupKey);

      const sameVidItems = arr.filter((x) => (isApple ? vidOf(x) === '05AC' || /iphone|ipad|apple mobile/i.test(x.FriendlyName || '') : vidOf(x) === vid));
      const hasOk = sameVidItems.some((x) => x.Status === 'OK');
      const hasIssue = !hasOk && sameVidItems.some((x) => x.Status && x.Status !== 'OK');

      out.push({
        vid: vid || (isApple ? '05AC' : ''),
        kind: isApple ? 'ios' : 'android',
        vendor: isApple ? 'Apple' : VENDORS[vid] || 'Android',
        name: fname || (isApple ? 'Apple iPhone' : 'Android Device'),
        status: hasOk ? 'OK' : d.Status || 'Unknown',
        issue: hasIssue
      });
    }
    usbCache.t = Date.now();
    usbCache.data = out;
    usbCache.pending = null;
    return out;
  })();

  return usbCache.pending;
}

let appleEnvCache = { t: 0, data: null, pending: null };
async function checkAppleEnv(force = false) {
  if (!force && appleEnvCache.data && Date.now() - appleEnvCache.t < 25000) return appleEnvCache.data;
  if (appleEnvCache.pending) return appleEnvCache.pending;

  appleEnvCache.pending = (async () => {
    const script = `
      $res = @{
        usbaaplSys = (Test-Path "$env:SystemRoot\\System32\\drivers\\usbaapl64.sys") -or (Test-Path "$env:SystemRoot\\System32\\drivers\\usbaapl.sys");
        amdsService = $false;
        amdsRunning = $false;
        appleStoreApp = $false;
        bonjourInstalled = $false;
        bonjourRunning = $false;
        pnpAppleOk = $false;
        firewallRule = $false;
      }
      $s1 = Get-Service -Name 'Apple Mobile Device Service','AppleMobileDeviceService' -ErrorAction SilentlyContinue | Select-Object -First 1
      if ($s1) { $res.amdsService = $true; $res.amdsRunning = ($s1.Status -eq 'Running') }
      $appx = Get-AppxPackage -Name '*AppleDevices*','*iTunes*' -ErrorAction SilentlyContinue | Select-Object -First 1
      if ($appx) { $res.appleStoreApp = $true }
      $bj = Get-Service -Name 'Bonjour Service' -ErrorAction SilentlyContinue | Select-Object -First 1
      if ($bj) { $res.bonjourInstalled = $true; $res.bonjourRunning = ($bj.Status -eq 'Running') }
      $pnp = Get-PnpDevice -PresentOnly -ErrorAction SilentlyContinue | Where-Object { ($_.InstanceId -match 'VID_05AC' -or $_.FriendlyName -match 'Apple Mobile Device|Apple iPhone') -and $_.Status -eq 'OK' } | Select-Object -First 1
      if ($pnp) { $res.pnpAppleOk = $true }
      $fw = Get-NetFirewallRule -DisplayName 'DZMirror AirPlay*' -ErrorAction SilentlyContinue | Select-Object -First 1
      if ($fw) { $res.firewallRule = $true }
      $res | ConvertTo-Json -Compress
    `;
    const r = await ps(script, 10000);
    let info = {
      usbaaplSys: false,
      amdsService: false,
      amdsRunning: false,
      appleStoreApp: false,
      bonjourInstalled: false,
      bonjourRunning: false,
      pnpAppleOk: false,
      firewallRule: false
    };
    try {
      const parsed = JSON.parse(r.out);
      if (parsed) Object.assign(info, parsed);
    } catch (e) { /* ignore */ }

    const driverInstalled = Boolean(info.usbaaplSys || info.amdsService || info.appleStoreApp || info.pnpAppleOk);
    const uxPath = findUxplay();
    const data = {
      ...info,
      driverInstalled,
      uxplayFound: Boolean(uxPath),
      uxplayPath: uxPath || '',
      airplayRunning: airplay.running,
      airplayConnected: airplay.connected,
      ips: getLocalIPs()
    };
    appleEnvCache.t = Date.now();
    appleEnvCache.data = data;
    appleEnvCache.pending = null;
    return data;
  })();

  return appleEnvCache.pending;
}

function findExeRecursive(dir, targetName, depth = 0) {
  if (depth > 3 || !dir || !fs.existsSync(dir)) return null;
  try {
    for (const f of fs.readdirSync(dir, { withFileTypes: true })) {
      const full = path.join(dir, f.name);
      if (f.isFile() && f.name.toLowerCase() === targetName) return full;
      if (f.isDirectory()) {
        const hit = findExeRecursive(full, targetName, depth + 1);
        if (hit) return hit;
      }
    }
  } catch (e) { /* ignore */ }
  return null;
}

function findUxplay() {
  const localUx = path.join(process.env.LOCALAPPDATA || '', 'DZMirror', 'uxplay');
  const candidates = [
    airplay.customPath,
    path.join(BIN, 'uxplay', 'uxplay.exe'),
    path.join(BIN, 'uxplay.exe'),
    path.join(localUx, 'uxplay.exe'),
    path.join(process.env.ProgramFiles || 'C:\\Program Files', 'UxPlay', 'uxplay.exe'),
    path.join(process.env.ProgramFiles || 'C:\\Program Files', 'uxplay-windows', 'uxplay.exe')
  ].filter(Boolean);
  for (const c of candidates) {
    if (fs.existsSync(c)) return c;
  }
  return findExeRecursive(localUx, 'uxplay.exe') || findExeRecursive(path.join(BIN, 'uxplay'), 'uxplay.exe');
}

function findInf(dir, names = ['android_winusb.inf']) {
  try {
    for (const f of fs.readdirSync(dir, { withFileTypes: true })) {
      const p = path.join(dir, f.name);
      if (f.isDirectory()) {
        const r = findInf(p, names);
        if (r) return r;
      } else if (names.includes(f.name.toLowerCase())) {
        return p;
      }
    }
  } catch (e) { /* ignore */ }
  return null;
}

function getActiveSummary() {
  const out = {};
  for (const [serial, s] of sessions.entries()) {
    out[serial] = {
      recording: Boolean(s.recording),
      recStart: s.recStart || 0,
      recFile: s.recFile || '',
      opts: s.opts || {},
      restarting: restarting.has(serial)
    };
  }
  return out;
}

// Fast detect: never blocks on slow PowerShell calls if cache exists; refreshes USB/Apple in background
async function detect() {
  const devices = await listDevices();

  // Trigger background refresh without blocking UI response if cache is stale
  if (Date.now() - usbCache.t >= 15000 && !usbCache.pending) scanUsb(true).catch(() => {});
  if (Date.now() - appleEnvCache.t >= 25000 && !appleEnvCache.pending) checkAppleEnv(true).catch(() => {});

  const usb = usbCache.data || [];
  const appleEnv = appleEnvCache.data || {
    driverInstalled: false,
    uxplayFound: Boolean(findUxplay()),
    airplayRunning: airplay.running,
    airplayConnected: airplay.connected,
    ips: getLocalIPs()
  };

  return {
    ok: true,
    devices,
    usb,
    appleDriver: appleEnv.driverInstalled,
    appleEnv,
    active: [...sessions.keys()],
    sessions: getActiveSummary(),
    airplay: {
      running: airplay.running,
      connected: airplay.connected,
      name: airplay.name,
      uxplayFound: Boolean(findUxplay())
    },
    overlayActive: Boolean(overlayWin && !overlayWin.isDestroyed()),
    overlaySerial: overlayTargetSerial
  };
}

function pushDevicesSnapshot() {
  detect().then((d) => sendMain('devices:update', d)).catch(() => {});
}

// ---------- Graceful Scrcpy Stream Engine + Hot-Swap Quality + Recording ----------
function buildScrcpyArgs(serial, o, recFile) {
  const winTitle = `DZ Mirror - ${o.title || serial}`;
  const fps = Number(o.fps) || 60;
  const bitrate = Number(o.bitrate) || 24;
  const codec = o.codec || 'h264';
  const a = [
    '-s', serial,
    `--window-title=${winTitle}`,
    `--max-fps=${fps}`,
    `--video-bit-rate=${bitrate}M`,
    `--video-codec=${codec}`,
    o.mode === 'fast' ? '--video-buffer=0' : '--video-buffer=50',
    '--render-driver=direct3d'
  ];

  const maxSize = Number(o.maxSize) || 0;
  if (maxSize > 0) a.push(`--max-size=${maxSize}`);

  if (o.audio && (Number(o.sdk) || 0) >= 30) {
    a.push(o.mode === 'fast' ? '--audio-buffer=35' : '--audio-buffer=80');
  } else {
    a.push('--no-audio');
  }

  if (o.awake) a.push('--stay-awake');
  if (o.off) a.push('--turn-screen-off');
  if (o.touch) a.push('--show-touches');
  if (o.top) a.push('--always-on-top');
  if (o.borderless) a.push('--window-borderless');
  if (o.view) a.push('--no-control');

  if (recFile) {
    a.push(`--record=${recFile}`);
  }
  return { args: a, winTitle };
}

async function stopStreamGracefully(serial) {
  const sess = sessions.get(serial);
  if (!sess || !sess.proc) return;
  const proc = sess.proc;
  const pid = proc.pid;

  const exited = new Promise((resolve) => {
    if (proc.exitCode !== null) return resolve();
    proc.once('exit', () => resolve());
  });

  if (pid && process.platform === 'win32') {
    ps(`$p = Get-Process -Id ${pid} -ErrorAction SilentlyContinue; if ($p) { $p.CloseMainWindow() | Out-Null }`, 2500).catch(() => {});
  } else {
    try { proc.kill('SIGINT'); } catch (e) { /* ignore */ }
  }

  await Promise.race([exited, sleep(sess.recording ? 1800 : 800)]);

  if (proc.exitCode === null) {
    if (pid && process.platform === 'win32') {
      await run('taskkill.exe', ['/PID', String(pid), '/T', '/F'], 3500);
    } else {
      try { proc.kill('SIGKILL'); } catch (e) { /* ignore */ }
    }
    await Promise.race([exited, sleep(400)]);
  }
  sessions.delete(serial);
}

function spawnStream(serial, o, recFile = null, recOpts = null) {
  if (!fs.existsSync(SCRCPY)) return { ok: false, msg: 'محرك البث (scrcpy.exe) غير موجود في مجلد bin' };

  const effectiveOpts = Object.assign({}, o);
  if (recFile && recOpts && recOpts.quality && recOpts.quality !== 'match') {
    if (recOpts.quality === '720p60') { effectiveOpts.maxSize = 1280; effectiveOpts.fps = 60; effectiveOpts.bitrate = 12; }
    else if (recOpts.quality === '1080p60') { effectiveOpts.maxSize = 1920; effectiveOpts.fps = 60; effectiveOpts.bitrate = 24; }
    else if (recOpts.quality === 'orig40') { effectiveOpts.maxSize = 0; effectiveOpts.fps = 60; effectiveOpts.bitrate = 40; }
  }

  const { args, winTitle } = buildScrcpyArgs(serial, effectiveOpts, recFile);
  const log = [];
  const c = spawn(SCRCPY, args, { windowsHide: true, env: { ...process.env, ADB } });

  const sess = {
    proc: c,
    opts: o,
    title: o.title || serial,
    sdk: o.sdk || 0,
    windowTitle: winTitle,
    recording: Boolean(recFile),
    recFile: recFile || '',
    recStart: recFile ? Date.now() : 0,
    recOpts: recOpts || null
  };
  sessions.set(serial, sess);

  const grab = (b) => {
    log.push(...String(b).split(/\r?\n/).filter(Boolean));
    if (log.length > 40) log.splice(0, log.length - 40);
  };
  c.stdout.on('data', grab);
  c.stderr.on('data', grab);

  c.on('error', (err) => {
    if (sessions.get(serial)?.proc === c) sessions.delete(serial);
    if (!restarting.has(serial)) {
      sendMain('stream:ended', { serial, code: -1, msg: String(err) });
      pushDevicesSnapshot();
    }
  });

  c.on('exit', (code) => {
    const isCurrent = sessions.get(serial)?.proc === c;
    if (isCurrent) sessions.delete(serial);
    if (restarting.has(serial)) return;

    if (overlayTargetSerial === serial) closeKeymapOverlay();

    const bad = log.filter((l) => /ERROR/i.test(l)).slice(-2).join(' | ');
    sendMain('stream:ended', {
      serial,
      code,
      msg: code ? bad : '',
      recFile: sess.recFile || ''
    });
    pushDevicesSnapshot();
  });

  sendMain('stream:state', { serial, active: true, recording: sess.recording, recStart: sess.recStart });
  pushDevicesSnapshot();
  return { ok: true, recFile: sess.recFile };
}

// ---------- Keymap Storage & Overlay Window ----------
function keymapFile() {
  return path.join(app.getPath('userData'), 'keymaps.json');
}
function bridgeConfigFile() {
  return path.join(app.getPath('userData'), 'keymap_runtime.json');
}

function loadKeymaps() {
  try {
    const p = keymapFile();
    if (fs.existsSync(p)) {
      const parsed = JSON.parse(fs.readFileSync(p, 'utf8'));
      if (parsed && Array.isArray(parsed.profiles) && parsed.profiles.length) return parsed;
    }
  } catch (e) { /* ignore */ }
  return JSON.parse(JSON.stringify(DEFAULT_KEYMAPS));
}

function saveKeymaps(data) {
  try {
    fs.writeFileSync(keymapFile(), JSON.stringify(data, null, 2), 'utf8');
    return true;
  } catch (e) {
    return false;
  }
}

function writeBridgeConfig() {
  try {
    fs.writeFileSync(
      bridgeConfigFile(),
      JSON.stringify({
        enabled: overlayConfig.enabled,
        editMode: overlayConfig.editMode,
        buttons: overlayConfig.buttons || []
      }),
      'utf8'
    );
  } catch (e) { /* ignore */ }
}

function stopKeymapBridge() {
  if (bridgeProc) {
    try { bridgeProc.kill(); } catch (e) { /* ignore */ }
    bridgeProc = null;
  }
}

function startKeymapBridge(windowTitle) {
  stopKeymapBridge();
  const scriptPath = path.join(HELPERS, 'keymap_bridge.ps1');
  if (!fs.existsSync(scriptPath)) return;
  writeBridgeConfig();

  bridgeProc = spawn(
    'powershell.exe',
    ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', scriptPath, '-WindowTitle', windowTitle, '-ConfigPath', bridgeConfigFile()],
    { windowsHide: true }
  );

  let buf = '';
  bridgeProc.stdout.on('data', (chunk) => {
    buf += String(chunk);
    const lines = buf.split(/\r?\n/);
    buf = lines.pop() || '';
    for (const raw of lines) {
      const line = raw.trim();
      if (!line) continue;
      if (line.startsWith('BOUNDS:')) {
        const parts = line.slice(7).split(',').map(Number);
        const [vis, x, y, w, h] = parts;
        if (overlayWin && !overlayWin.isDestroyed()) {
          if (vis === 1 && w > 20 && h > 20) {
            const sf = screen.getDisplayNearestPoint({ x, y }).scaleFactor || 1;
            overlayWin.setBounds({
              x: Math.round(x / sf),
              y: Math.round(y / sf),
              width: Math.round(w / sf),
              height: Math.round(h / sf)
            });
            if (!overlayWin.isVisible()) overlayWin.showInactive();
          } else if (!overlayConfig.editMode) {
            overlayWin.hide();
          }
        }
      } else if (line === 'TOGGLE_VIS') {
        overlayConfig.visible = !overlayConfig.visible;
        sendOverlay('overlay:data', overlayConfig);
        sendMain('keymap:event', { type: 'visibility', visible: overlayConfig.visible });
      } else if (line.startsWith('KEY:')) {
        const [, id, state] = line.split(':');
        sendOverlay('keymap:event', { type: 'press', id, active: state === '1' });
      }
    }
  });

  bridgeProc.on('exit', () => {
    bridgeProc = null;
  });
}

function closeKeymapOverlay() {
  stopKeymapBridge();
  overlayTargetSerial = null;
  if (overlayWin && !overlayWin.isDestroyed()) {
    overlayWin.close();
  }
  overlayWin = null;
  sendMain('keymap:event', { type: 'closed' });
  pushDevicesSnapshot();
}

function openKeymapOverlay(serial, cfg) {
  const sess = sessions.get(serial);
  if (!sess) return { ok: false, msg: 'ابدأ بث شاشة الهاتف أولاً لتفعيل طبقة أزرار التحكم' };

  overlayTargetSerial = serial;
  if (cfg) Object.assign(overlayConfig, cfg);

  if (overlayWin && !overlayWin.isDestroyed()) {
    sendOverlay('overlay:data', overlayConfig);
    writeBridgeConfig();
    pushDevicesSnapshot();
    return { ok: true };
  }

  overlayWin = new BrowserWindow({
    width: 420,
    height: 760,
    transparent: true,
    frame: false,
    resizable: false,
    skipTaskbar: true,
    alwaysOnTop: true,
    hasShadow: false,
    focusable: false,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false
    }
  });

  overlayWin.setAlwaysOnTop(true, 'screen-saver');
  overlayWin.setIgnoreMouseEvents(!overlayConfig.editMode, { forward: true });
  overlayWin.loadFile(path.join(__dirname, 'renderer', 'overlay.html'));
  overlayWin.webContents.once('did-finish-load', () => {
    sendOverlay('overlay:data', overlayConfig);
  });
  overlayWin.on('closed', () => {
    stopKeymapBridge();
    overlayWin = null;
    overlayTargetSerial = null;
    sendMain('keymap:event', { type: 'closed' });
    pushDevicesSnapshot();
  });

  startKeymapBridge(sess.windowTitle);
  pushDevicesSnapshot();
  return { ok: true };
}

// ---------- Main Window ----------
function createWindow() {
  const icon = path.join(__dirname, 'build', 'icon.png');
  win = new BrowserWindow({
    width: 1260,
    height: 800,
    minWidth: 1000,
    minHeight: 660,
    backgroundColor: '#000000',
    title: 'DZ Mirror Pro',
    icon: fs.existsSync(icon) ? icon : undefined,
    titleBarStyle: 'hidden',
    titleBarOverlay: { color: '#050507', symbolColor: '#f5f5f7', height: 44 },
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false
    }
  });
  win.setMenuBarVisibility(false);
  win.loadFile(path.join(__dirname, 'renderer', 'index.html'));
}

if (!app.requestSingleInstanceLock()) app.quit();
app.on('second-instance', () => {
  if (win) {
    if (win.isMinimized()) win.restore();
    win.focus();
  }
});

app.whenReady().then(() => {
  if (fs.existsSync(ADB)) adb(['start-server'], 15000).catch(() => {});
  // Warm caches in background on startup
  scanUsb(true).catch(() => {});
  checkAppleEnv(true).catch(() => {});
  createWindow();
});

app.on('window-all-closed', () => app.quit());
app.on('will-quit', () => {
  closeKeymapOverlay();
  if (airplay.proc) {
    try { airplay.proc.kill(); } catch (e) { /* ignore */ }
  }
  for (const s of sessions.values()) {
    try { s.proc.kill(); } catch (e) { /* ignore */ }
  }
  try {
    if (fs.existsSync(ADB)) spawnSync(ADB, ['kill-server'], { windowsHide: true, timeout: 4000 });
  } catch (e) { /* ignore */ }
});

// ---------- IPC Handlers ----------
ipcMain.handle('detect', () => detect());
ipcMain.handle('sys:ips', () => ({ ok: true, ips: getLocalIPs() }));

ipcMain.handle('sys:health', async () => {
  const appleEnv = await checkAppleEnv(true);
  return {
    ok: true,
    adb: fs.existsSync(ADB),
    scrcpy: fs.existsSync(SCRCPY),
    uxplay: appleEnv.uxplayFound,
    uxplayPath: appleEnv.uxplayPath,
    appleDriver: appleEnv.driverInstalled,
    bonjourInstalled: appleEnv.bonjourInstalled,
    bonjourRunning: appleEnv.bonjourRunning,
    firewallRule: appleEnv.firewallRule,
    ips: appleEnv.ips
  };
});

ipcMain.handle('adb:restart', async () => {
  if (!fs.existsSync(ADB)) return { ok: false, msg: 'ملف adb.exe غير موجود في مجلد bin' };
  await adb(['kill-server']);
  await adb(['start-server'], 15000);
  usbCache.t = 0;
  deviceInfoCache.clear();
  scanUsb(true).catch(() => {});
  pushDevicesSnapshot();
  return { ok: true };
});

// Stream Start / Stop / Seamless Hot-Swap Apply
ipcMain.handle('stream:start', (_e, serial, o) => {
  if (sessions.has(serial)) return { ok: false, msg: 'البث يعمل بالفعل لهذا الجهاز' };
  let recFile = null;
  if (o.rec) {
    const dir = path.join(app.getPath('videos'), 'DZMirror');
    fs.mkdirSync(dir, { recursive: true });
    const ext = o.recFormat === 'mp4' ? 'mp4' : 'mkv';
    recFile = path.join(dir, `${(o.title || 'phone').replace(/[^\w.-]+/g, '_')}-${stamp()}.${ext}`);
  }
  return spawnStream(serial, o, recFile, o.rec ? { quality: o.recQuality || 'match', format: o.recFormat || 'mkv' } : null);
});

ipcMain.handle('stream:stop', async (_e, serial) => {
  if (overlayTargetSerial === serial) closeKeymapOverlay();
  await stopStreamGracefully(serial);
  sendMain('stream:state', { serial, active: false, recording: false });
  pushDevicesSnapshot();
  return { ok: true };
});

ipcMain.handle('stream:apply', async (_e, serial, newOpts) => {
  const existing = sessions.get(serial);
  if (!existing) return { ok: false, msg: 'لا يوجد بث نشط لتحديثه' };
  if (restarting.has(serial)) return { ok: false, msg: 'جارٍ تطبيق التغييرات بالفعل…' };

  restarting.add(serial);
  const wasOverlayOpen = overlayTargetSerial === serial;
  const mergedOpts = Object.assign({}, existing.opts, newOpts, { title: existing.title, sdk: existing.sdk });

  try {
    await stopStreamGracefully(serial);
    await sleep(220);
    const res = spawnStream(serial, mergedOpts, null, null);
    if (res.ok && wasOverlayOpen) {
      const s = sessions.get(serial);
      if (s) startKeymapBridge(s.windowTitle);
    }
    return res;
  } finally {
    setTimeout(() => restarting.delete(serial), 300);
  }
});

// Dedicated On-Demand Screen Recording
ipcMain.handle('record:start', async (_e, serial, recOpts = {}) => {
  const existing = sessions.get(serial);
  if (!existing) return { ok: false, msg: 'ابدأ بث شاشة الهاتف أولاً ثم اضغط تسجيل' };
  if (existing.recording) return { ok: false, msg: 'التسجيل يعمل بالفعل' };
  if (restarting.has(serial)) return { ok: false, msg: 'انتظر لحظة حتى يكتمل تحديث البث' };

  const dir = path.join(app.getPath('videos'), 'DZMirror');
  fs.mkdirSync(dir, { recursive: true });
  const ext = recOpts.format === 'mp4' ? 'mp4' : 'mkv';
  const recFile = path.join(dir, `${(existing.title || 'phone').replace(/[^\w.-]+/g, '_')}-${stamp()}.${ext}`);

  restarting.add(serial);
  const wasOverlayOpen = overlayTargetSerial === serial;
  const baseOpts = Object.assign({}, existing.opts, {
    title: existing.title,
    sdk: existing.sdk,
    audio: recOpts.audio !== undefined ? Boolean(recOpts.audio) : existing.opts.audio
  });

  try {
    await stopStreamGracefully(serial);
    await sleep(220);
    const res = spawnStream(serial, baseOpts, recFile, recOpts);
    if (res.ok && wasOverlayOpen) {
      const s = sessions.get(serial);
      if (s) startKeymapBridge(s.windowTitle);
    }
    return { ok: res.ok, file: recFile, msg: res.ok ? 'بدأ تسجيل الشاشة بسلاسة' : res.msg };
  } finally {
    setTimeout(() => restarting.delete(serial), 300);
  }
});

ipcMain.handle('record:stop', async (_e, serial) => {
  const existing = sessions.get(serial);
  if (!existing || !existing.recording) return { ok: false, msg: 'لا يوجد تسجيل نشط حالياً' };

  const savedFile = existing.recFile;
  restarting.add(serial);
  const wasOverlayOpen = overlayTargetSerial === serial;
  const baseOpts = Object.assign({}, existing.opts, { title: existing.title, sdk: existing.sdk, rec: false });

  try {
    await stopStreamGracefully(serial);
    await sleep(240);
    const res = spawnStream(serial, baseOpts, null, null);
    if (res.ok && wasOverlayOpen) {
      const s = sessions.get(serial);
      if (s) startKeymapBridge(s.windowTitle);
    }
    return { ok: true, file: savedFile, msg: 'تم حفظ التسجيل بنجاح ومواصلة البث' };
  } finally {
    setTimeout(() => restarting.delete(serial), 300);
  }
});

ipcMain.handle('recordings:list', () => {
  const dir = path.join(app.getPath('videos'), 'DZMirror');
  fs.mkdirSync(dir, { recursive: true });
  try {
    const files = fs
      .readdirSync(dir)
      .filter((f) => /\.(mp4|mkv|webm)$/i.test(f))
      .map((name) => {
        const full = path.join(dir, name);
        const st = fs.statSync(full);
        return { name, path: full, size: st.size, mtime: st.mtimeMs };
      })
      .sort((a, b) => b.mtime - a.mtime)
      .slice(0, 20);
    return { ok: true, dir, files };
  } catch (e) {
    return { ok: true, dir, files: [] };
  }
});

ipcMain.handle('file:open', (_e, filePath) => {
  if (filePath && fs.existsSync(filePath)) {
    shell.openPath(filePath);
    return { ok: true };
  }
  return { ok: false };
});
ipcMain.handle('file:reveal', (_e, filePath) => {
  if (filePath && fs.existsSync(filePath)) {
    shell.showItemInFolder(filePath);
    return { ok: true };
  }
  return { ok: false };
});

// Screenshot
ipcMain.handle('shot', (_e, serial, name) => new Promise((res) => {
  const dir = path.join(app.getPath('pictures'), 'DZMirror');
  fs.mkdirSync(dir, { recursive: true });
  const file = path.join(dir, `${(name || 'phone').replace(/[^\w.-]+/g, '_')}-${stamp()}.png`);
  const p = spawn(ADB, ['-s', serial, 'exec-out', 'screencap', '-p'], { windowsHide: true });
  const ws = fs.createWriteStream(file);
  p.stdout.pipe(ws);
  ws.on('finish', () => {
    try {
      res({ ok: fs.statSync(file).size > 1000, file });
    } catch (e) {
      res({ ok: false });
    }
  });
  p.on('error', () => res({ ok: false }));
}));

// Wi-Fi ADB
ipcMain.handle('wifi:enable', async (_e, serial) => {
  const r = await adb(['-s', serial, 'shell', 'ip', '-f', 'inet', 'addr', 'show', 'wlan0']);
  const m = /inet (\d+\.\d+\.\d+\.\d+)/.exec(r.out);
  if (!m) return { ok: false, msg: 'تعذّر معرفة عنوان الواي فاي، تأكد أن الهاتف متصل بنفس شبكة الواي فاي' };
  await adb(['-s', serial, 'tcpip', '5555']);
  await sleep(1400);
  const c = await adb(['connect', `${m[1]}:5555`]);
  pushDevicesSnapshot();
  return { ok: /connected/i.test(c.out), msg: c.out || c.err, ip: m[1] };
});

ipcMain.handle('wifi:connect', async (_e, host) => {
  const h = String(host || '').trim();
  if (!/^[\w.\-]+(:\d+)?$/.test(h)) return { ok: false, msg: 'عنوان IP غير صحيح' };
  const c = await adb(['connect', h.includes(':') ? h : `${h}:5555`], 15000);
  pushDevicesSnapshot();
  return { ok: /connected/i.test(c.out) && !/cannot|failed/i.test(c.out), msg: c.out || c.err };
});

ipcMain.handle('wifi:pair', async (_e, host, code) => {
  if (!/^[\w.\-]+:\d+$/.test(String(host || '').trim()) || !/^\d{6}$/.test(String(code || '').trim())) {
    return { ok: false, msg: 'أدخل العنوان مع المنفذ (مثل 192.168.1.5:37123) والرمز المكوّن من 6 أرقام' };
  }
  const r = await adb(['pair', host.trim(), code.trim()], 20000);
  return { ok: /success/i.test(r.out), msg: r.out || r.err };
});

ipcMain.handle('wifi:disconnect', async (_e, serial) => {
  await adb(['disconnect', serial]);
  pushDevicesSnapshot();
  return { ok: true };
});

function installRootDir() {
  return path.join(process.env.LOCALAPPDATA || app.getPath('userData'), 'DZMirror');
}

async function runAppleInstaller(target) {
  const scriptPath = path.join(HELPERS, 'install_apple.ps1');
  if (!fs.existsSync(scriptPath)) return { ok: false, msg: 'ملف التثبيت helpers/install_apple.ps1 غير موجود' };
  const r = await run(
    'powershell.exe',
    ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', scriptPath, '-Target', target, '-InstallRoot', installRootDir()],
    240000
  );
  appleEnvCache.t = 0;
  usbCache.t = 0;
  await checkAppleEnv(true);
  pushDevicesSnapshot();
  return r;
}

// Drivers (Android & Apple) - Direct Install without Microsoft Store
ipcMain.handle('driver:fix', async (_e, kind = 'android') => {
  if (kind === 'ios') {
    const r = await runAppleInstaller('driver');
    return {
      ok: r.ok,
      msg: r.ok ? 'تم تحميل وتثبيت تعريفات Apple USB بنجاح' : ('تعذّر التثبيت التلقائي: ' + (r.err || r.out || 'تأكد من الاتصال بالإنترنت'))
    };
  }
  const inf = findInf(path.join(BIN, 'driver'), ['android_winusb.inf']);
  if (!inf) {
    const scriptPath = path.join(HELPERS, 'install_android_driver.ps1');
    const r = await run(
      'powershell.exe',
      ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', scriptPath, '-InstallRoot', installRootDir()],
      180000
    );
    if (fs.existsSync(ADB)) { await adb(['kill-server']); await adb(['start-server'], 15000); }
    usbCache.t = 0;
    scanUsb(true).catch(() => {});
    return {
      ok: r.ok,
      msg: r.ok ? 'تم تحميل وتثبيت تعريفات أندرويد مباشرة بنجاح' : ('فشل تثبيت التعريفات: ' + (r.err || r.out || 'تحقق من الإنترنت وصلاحية المسؤول'))
    };
  }
  const safe = inf.replace(/'/g, "''");
  const r = await ps(`Start-Process -FilePath pnputil.exe -ArgumentList '/add-driver "${safe}" /install' -Verb RunAs -Wait`, 120000);
  await run('pnputil.exe', ['/scan-devices']);
  if (fs.existsSync(ADB)) {
    await adb(['kill-server']);
    await adb(['start-server'], 15000);
  }
  usbCache.t = 0;
  scanUsb(true).catch(() => {});
  return { ok: r.ok, msg: r.ok ? 'تم تثبيت التعريفات بنجاح. افصل الهاتف وأعد توصيله' : 'أُلغي التثبيت أو لم تُمنح صلاحية المسؤول' };
});

ipcMain.handle('oem:open', (_e, vendor) => {
  const q = encodeURIComponent(`${String(vendor).split(' ')[0]} USB driver Windows`);
  shell.openExternal(`https://www.google.com/search?q=${q}`);
  return { ok: true };
});

// Apple / iPhone & AirPlay Management (Direct Installers, Zero Microsoft Store)
ipcMain.handle('apple:env', () => checkAppleEnv(true));

ipcMain.handle('apple:driver', async () => {
  const r = await runAppleInstaller('driver');
  return {
    ok: r.ok,
    msg: r.ok ? 'تم تحميل وتثبيت تعريفات Apple USB مباشرة بنجاح' : ('تعذّر التثبيت التلقائي: ' + (r.err || r.out))
  };
});

ipcMain.handle('apple:bonjour', async () => {
  const r = await runAppleInstaller('bonjour');
  return {
    ok: r.ok,
    msg: r.ok ? 'تم تحميل وتثبيت خدمة Bonjour بنجاح' : ('تعذّر تثبيت Bonjour تلقائياً: ' + (r.err || r.out))
  };
});

ipcMain.handle('apple:install-uxplay', async () => {
  const r = await runAppleInstaller('uxplay');
  const found = Boolean(findUxplay());
  return {
    ok: r.ok && found,
    msg: found ? 'تم تحميل وتجهيز محرك AirPlay (uxplay.exe) بنجاح! يمكنك بدء البث الآن' : ('تعذّر تحميل uxplay.exe تلقائياً: ' + (r.err || r.out))
  };
});

ipcMain.handle('apple:firewall', async () => {
  const ux = findUxplay();
  const cmds = [
    `New-NetFirewallRule -DisplayName 'DZMirror AirPlay TCP' -Direction Inbound -Protocol TCP -LocalPort 7000,7001,7100,47000 -Action Allow -ErrorAction SilentlyContinue`,
    `New-NetFirewallRule -DisplayName 'DZMirror AirPlay UDP' -Direction Inbound -Protocol UDP -LocalPort 5353,6000-6005,7010-7011 -Action Allow -ErrorAction SilentlyContinue`
  ];
  if (ux) {
    const safeUx = ux.replace(/'/g, "''");
    cmds.push(`New-NetFirewallRule -DisplayName 'DZMirror AirPlay UxPlay' -Direction Inbound -Program '${safeUx}' -Action Allow -ErrorAction SilentlyContinue`);
  }
  const joined = cmds.join('; ');
  const r = await ps(`Start-Process powershell -Verb RunAs -Wait -ArgumentList '-NoProfile -ExecutionPolicy Bypass -Command "${joined}"'`, 60000);
  appleEnvCache.t = 0;
  return {
    ok: r.ok,
    msg: r.ok ? 'تم فتح منافذ AirPlay و mDNS في جدار حماية ويندوز بنجاح' : 'لم يتم منح صلاحية المسؤول لتعديل جدار الحماية'
  };
});

ipcMain.handle('apple:airplay:pick', async () => {
  const res = await dialog.showOpenDialog(win, {
    title: 'اختر ملف uxplay.exe',
    filters: [{ name: 'Executable', extensions: ['exe'] }],
    properties: ['openFile']
  });
  if (res.canceled || !res.filePaths.length) return { ok: false };
  airplay.customPath = res.filePaths[0];
  appleEnvCache.t = 0;
  return { ok: true, path: airplay.customPath };
});

ipcMain.handle('apple:airplay:start', async (_e, cfg = {}) => {
  if (airplay.running && airplay.proc) {
    return { ok: true, msg: `مستقبل AirPlay يعمل بالفعل باسم "${airplay.name}"` };
  }
  const ux = findUxplay();
  if (!ux) {
    return {
      ok: false,
      code: 'NO_UXPLAY',
      msg: 'ملف مستقبِل AirPlay (uxplay.exe) غير موجود في مجلد bin/uxplay. يمكنك تحديد مساره يدوياً.'
    };
  }

  const env = await checkAppleEnv(true);
  if (!env.bonjourRunning && env.bonjourInstalled) {
    await ps("Start-Service -Name 'Bonjour Service' -ErrorAction SilentlyContinue", 5000);
  }

  airplay.name = (cfg.name || 'DZ Mirror').trim() || 'DZ Mirror';
  airplay.resolution = cfg.resolution || '1920x1080';
  airplay.fps = Number(cfg.fps) || 60;
  airplay.audio = cfg.audio !== false;
  airplay.logs = [];
  airplay.connected = false;

  const args = [
    '-n', airplay.name,
    '-s', `${airplay.resolution}@${airplay.fps}`,
    '-fps', String(airplay.fps),
    '-nohold'
  ];
  if (!airplay.audio) args.push('-a', 'off');

  try {
    const p = spawn(ux, args, {
      cwd: path.dirname(ux),
      windowsHide: true,
      env: { ...process.env }
    });
    airplay.proc = p;
    airplay.running = true;

    const pushLog = (chunk) => {
      const lines = String(chunk).split(/\r?\n/).filter(Boolean);
      for (const l of lines) {
        airplay.logs.push(l);
        if (airplay.logs.length > 40) airplay.logs.shift();
        if (/raop_rtp_mirror|connection established|begin video|Client connected/i.test(l)) {
          airplay.connected = true;
        }
        if (/Connection closed|reset|stopped/i.test(l)) {
          airplay.connected = false;
        }
      }
      sendMain('airplay:state', { running: airplay.running, connected: airplay.connected, name: airplay.name, logs: airplay.logs.slice(-8) });
    };

    p.stdout.on('data', pushLog);
    p.stderr.on('data', pushLog);
    p.on('error', (err) => {
      airplay.running = false;
      airplay.connected = false;
      airplay.proc = null;
      sendMain('airplay:state', { running: false, connected: false, error: String(err), logs: airplay.logs.slice(-8) });
    });
    p.on('exit', (code) => {
      airplay.running = false;
      airplay.connected = false;
      airplay.proc = null;
      sendMain('airplay:state', { running: false, connected: false, code, logs: airplay.logs.slice(-8) });
    });

    sendMain('airplay:state', { running: true, connected: false, name: airplay.name, logs: airplay.logs });
    return {
      ok: true,
      bonjourWarning: !env.bonjourInstalled,
      msg: env.bonjourInstalled
        ? `تم تشغيل AirPlay باسم "${airplay.name}". على الآيفون: مركز التحكم ← انعكاس الشاشة ← ${airplay.name}`
        : `تم تشغيل AirPlay، لكن خدمة Bonjour غير مثبتة — ثبّتها ليظهر "${airplay.name}" على الآيفون`
    };
  } catch (e) {
    airplay.running = false;
    return { ok: false, msg: 'تعذّر تشغيل مستقبِل AirPlay: ' + String(e) };
  }
});

ipcMain.handle('apple:airplay:stop', () => {
  if (airplay.proc) {
    try { airplay.proc.kill(); } catch (e) { /* ignore */ }
    airplay.proc = null;
  }
  airplay.running = false;
  airplay.connected = false;
  sendMain('airplay:state', { running: false, connected: false, name: airplay.name, logs: airplay.logs.slice(-8) });
  return { ok: true };
});

ipcMain.handle('apple:airplay:status', () => ({
  ok: true,
  running: airplay.running,
  connected: airplay.connected,
  name: airplay.name,
  logs: airplay.logs.slice(-12)
}));

// Keymap IPC
ipcMain.handle('keymap:load', () => ({ ok: true, data: loadKeymaps() }));
ipcMain.handle('keymap:save', (_e, data) => {
  const ok = saveKeymaps(data);
  if (ok && data) {
    const prof = (data.profiles || []).find((p) => p.id === data.activeProfileId) || (data.profiles || [])[0];
    overlayConfig.activeProfileId = data.activeProfileId;
    overlayConfig.opacity = data.opacity ?? overlayConfig.opacity;
    overlayConfig.visible = data.visible ?? overlayConfig.visible;
    overlayConfig.enabled = data.enabled ?? overlayConfig.enabled;
    overlayConfig.buttons = prof ? prof.buttons : [];
    writeBridgeConfig();
    sendOverlay('overlay:data', overlayConfig);
  }
  return { ok };
});

ipcMain.handle('keymap:overlay:open', (_e, serial, cfg) => openKeymapOverlay(serial, cfg));
ipcMain.handle('keymap:overlay:close', () => { closeKeymapOverlay(); return { ok: true }; });

ipcMain.handle('keymap:overlay:mode', (_e, editMode) => {
  overlayConfig.editMode = Boolean(editMode);
  if (overlayWin && !overlayWin.isDestroyed()) {
    overlayWin.setIgnoreMouseEvents(!overlayConfig.editMode, { forward: true });
    overlayWin.setFocusable(overlayConfig.editMode);
    if (overlayConfig.editMode) overlayWin.focus();
  }
  writeBridgeConfig();
  sendOverlay('overlay:data', overlayConfig);
  sendMain('keymap:event', { type: 'mode', editMode: overlayConfig.editMode });
  return { ok: true };
});

ipcMain.handle('keymap:overlay:config', (_e, partial) => {
  Object.assign(overlayConfig, partial || {});
  writeBridgeConfig();
  sendOverlay('overlay:data', overlayConfig);
  return { ok: true };
});

ipcMain.handle('keymap:overlay:visibility', (_e, visible) => {
  overlayConfig.visible = Boolean(visible);
  sendOverlay('overlay:data', overlayConfig);
  return { ok: true };
});

// Folders
ipcMain.handle('folder:open', (_e, kind) => {
  const dir = path.join(app.getPath(kind === 'video' ? 'videos' : 'pictures'), 'DZMirror');
  fs.mkdirSync(dir, { recursive: true });
  shell.openPath(dir);
  return { ok: true };
});
