param(
  [Parameter(Mandatory = $true)][ValidateSet('uxplay', 'bonjour', 'driver', 'all')][string]$Target,
  [Parameter(Mandatory = $true)][string]$InstallRoot,
  [string]$BundledDriverDir = ""
)

$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

New-Item -ItemType Directory -Force -Path $InstallRoot | Out-Null
$tmp = Join-Path $env:TEMP "DZMirror_Setup_$(Get-Random)"
New-Item -ItemType Directory -Force -Path $tmp | Out-Null

function Install-MsiQuiet($msiPath) {
  if (-not $msiPath -or -not (Test-Path $msiPath)) { return $false }
  $p = Start-Process -FilePath "msiexec.exe" -ArgumentList "/i `"$msiPath`" /qn /norestart" -Verb RunAs -PassThru -Wait
  return ($p.ExitCode -eq 0 -or $p.ExitCode -eq 3010 -or $p.ExitCode -eq 1638)
}

function Find-BundledMsi($pattern) {
  if ($BundledDriverDir -and (Test-Path $BundledDriverDir)) {
    return Get-ChildItem -Path $BundledDriverDir -Recurse -Filter $pattern -ErrorAction SilentlyContinue | Select-Object -First 1
  }
  return $null
}

function Install-UxPlay {
  $uxDir = Join-Path $InstallRoot "uxplay"
  New-Item -ItemType Directory -Force -Path $uxDir | Out-Null

  $rel = Invoke-RestMethod -Uri "https://api.github.com/repos/leapbtw/uxplay-windows/releases/latest" -Headers @{ "User-Agent" = "DZMirrorPro" } -TimeoutSec 25
  $zipAsset = $rel.assets | Where-Object { $_.name -match "x64.*\.zip$|\.zip$" -and $_.name -notmatch "arm64" } | Select-Object -First 1
  $msiAsset = $rel.assets | Where-Object { $_.name -match "x64.*\.msi$|\.msi$" -and $_.name -notmatch "arm64" } | Select-Object -First 1
  $exeAsset = $rel.assets | Where-Object { $_.name -match "\.exe$" -and $_.name -notmatch "arm64" } | Select-Object -First 1

  if ($zipAsset) {
    $zipPath = Join-Path $tmp "uxplay.zip"
    Invoke-WebRequest -Uri $zipAsset.browser_download_url -OutFile $zipPath -TimeoutSec 180
    Expand-Archive -Path $zipPath -DestinationPath $uxDir -Force
  } elseif ($msiAsset) {
    $msiPath = Join-Path $tmp "uxplay.msi"
    Invoke-WebRequest -Uri $msiAsset.browser_download_url -OutFile $msiPath -TimeoutSec 180
    Start-Process -FilePath "msiexec.exe" -ArgumentList "/a `"$msiPath`" /qn TARGETDIR=`"$uxDir`"" -Wait | Out-Null
  } elseif ($exeAsset) {
    $exePath = Join-Path $tmp "uxplay_setup.exe"
    Invoke-WebRequest -Uri $exeAsset.browser_download_url -OutFile $exePath -TimeoutSec 180
    Start-Process -FilePath $exePath -ArgumentList "/VERYSILENT /SUPPRESSMSGBOXES /NORESTART /DIR=`"$uxDir`"" -Wait
  } else {
    throw "لم يتم العثور على حزمة uxplay متوافقة"
  }

  $found = Get-ChildItem -Path $uxDir -Recurse -Include "uxplay.exe","uxplay-windows.exe" -ErrorAction SilentlyContinue | Select-Object -First 1
  if (-not $found) {
    throw "اكتمل التحميل لكن لم يُعثر على uxplay.exe داخل المجلد"
  }
  Write-Output "UXPLAY_OK:$($found.FullName)"
}

function Extract-AppleMsiFromItunes {
  $itunesExe = Join-Path $tmp "iTunes64Setup.exe"
  $extractDir = Join-Path $tmp "itunes_extracted"
  New-Item -ItemType Directory -Force -Path $extractDir | Out-Null

  Invoke-WebRequest -Uri "https://www.apple.com/itunes/download/win64" -OutFile $itunesExe -TimeoutSec 240

  $7z = Get-Command 7z -ErrorAction SilentlyContinue
  if (-not $7z -and (Test-Path "$env:ProgramFiles\7-Zip\7z.exe")) { $7z = "$env:ProgramFiles\7-Zip\7z.exe" }
  if (-not $7z -and (Test-Path "${env:ProgramFiles(x86)}\7-Zip\7z.exe")) { $7z = "${env:ProgramFiles(x86)}\7-Zip\7z.exe" }

  if ($7z) {
    & $7z x $itunesExe "-o$extractDir" -y | Out-Null
  } else {
    # Official iTunes64Setup.exe supports /extract when invoked with quotes, or fallback to winget
    Start-Process -FilePath $itunesExe -ArgumentList "/extract `"$extractDir`"" -Wait -ErrorAction SilentlyContinue
  }
  return $extractDir
}

function Install-AppleDriverDirect {
  # 1. Offline bundled MSI check first
  $bundled = Find-BundledMsi "AppleMobileDeviceSupport*.msi"
  if ($bundled -and (Install-MsiQuiet $bundled.FullName)) {
    Write-Output "DRIVER_OK_OFFLINE"
    return
  }

  # 2. Try extracting from Apple's official installer
  $done = $false
  try {
    $dir = Extract-AppleMsiFromItunes
    $msi = Get-ChildItem -Path $dir -Recurse -Filter "AppleMobileDeviceSupport64.msi" -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($msi -and (Install-MsiQuiet $msi.FullName)) { $done = $true }
  } catch { }

  # 3. Fallback via winget (direct package install, no store UI)
  if (-not $done -and (Get-Command winget -ErrorAction SilentlyContinue)) {
    & winget install --id Apple.iTunes --silent --accept-package-agreements --accept-source-agreements | Out-Null
    if ($LASTEXITCODE -eq 0) { $done = $true }
  }
  if (-not $done) { throw "تعذّر تثبيت تعريفات Apple تلقائياً." }
  Write-Output "DRIVER_OK"
}

function Install-BonjourDirect {
  # 1. Offline bundled MSI check first
  $bundled = Find-BundledMsi "Bonjour*.msi"
  if ($bundled -and (Install-MsiQuiet $bundled.FullName)) {
    Start-Service -Name "Bonjour Service" -ErrorAction SilentlyContinue
    Write-Output "BONJOUR_OK_OFFLINE"
    return
  }

  # 2. Try extracting from Apple's official installer
  $done = $false
  try {
    $dir = Extract-AppleMsiFromItunes
    $msi = Get-ChildItem -Path $dir -Recurse -Filter "Bonjour64.msi" -ErrorAction SilentlyContinue | Select-Object -First 1
    if (-not $msi) { $msi = Get-ChildItem -Path $dir -Recurse -Filter "Bonjour.msi" -ErrorAction SilentlyContinue | Select-Object -First 1 }
    if ($msi -and (Install-MsiQuiet $msi.FullName)) { $done = $true }
  } catch { }

  if (-not $done -and (Get-Command winget -ErrorAction SilentlyContinue)) {
    & winget install --id Apple.Bonjour --silent --accept-package-agreements --accept-source-agreements | Out-Null
    if ($LASTEXITCODE -eq 0) { $done = $true }
  }
  if (-not $done) { throw "تعذّر تثبيت Bonjour تلقائياً." }
  Start-Service -Name "Bonjour Service" -ErrorAction SilentlyContinue
  Write-Output "BONJOUR_OK"
}

try {
  if ($Target -eq 'uxplay' -or $Target -eq 'all') { Install-UxPlay }
  if ($Target -eq 'driver' -or $Target -eq 'all') { Install-AppleDriverDirect }
  if ($Target -eq 'bonjour' -or $Target -eq 'all') { Install-BonjourDirect }
} finally {
  Remove-Item -Path $tmp -Recurse -Force -ErrorAction SilentlyContinue
}
