param(
  [Parameter(Mandatory = $true)][ValidateSet('uxplay', 'bonjour', 'driver', 'all')][string]$Target,
  [Parameter(Mandatory = $true)][string]$InstallRoot
)

$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

New-Item -ItemType Directory -Force -Path $InstallRoot | Out-Null
$tmp = Join-Path $env:TEMP "DZMirror_Setup_$(Get-Random)"
New-Item -ItemType Directory -Force -Path $tmp | Out-Null

function Install-UxPlay {
  $uxDir = Join-Path $InstallRoot "uxplay"
  New-Item -ItemType Directory -Force -Path $uxDir | Out-Null

  # Try GitHub API for latest leapbtw/uxplay-windows release
  $rel = Invoke-RestMethod -Uri "https://api.github.com/repos/leapbtw/uxplay-windows/releases/latest" -Headers @{ "User-Agent" = "DZMirrorPro" } -TimeoutSec 25
  $zipAsset = $rel.assets | Where-Object { $_.name -match "\.zip$" } | Select-Object -First 1
  $exeAsset = $rel.assets | Where-Object { $_.name -match "installer.*\.exe$|\.exe$" } | Select-Object -First 1

  if ($zipAsset) {
    $zipPath = Join-Path $tmp "uxplay.zip"
    Invoke-WebRequest -Uri $zipAsset.browser_download_url -OutFile $zipPath -TimeoutSec 120
    Expand-Archive -Path $zipPath -DestinationPath $uxDir -Force
  } elseif ($exeAsset) {
    $exePath = Join-Path $tmp "uxplay_setup.exe"
    Invoke-WebRequest -Uri $exeAsset.browser_download_url -OutFile $exePath -TimeoutSec 120
    # Try silent Inno/NSIS install
    $p = Start-Process -FilePath $exePath -ArgumentList "/VERYSILENT /SUPPRESSMSGBOXES /NORESTART /DIR=`"$uxDir`"" -PassThru -Wait
    if ($p.ExitCode -ne 0) {
      Start-Process -FilePath $exePath -ArgumentList "/S /D=$uxDir" -Wait
    }
  } else {
    throw "No compatible UxPlay release asset found."
  }

  # Flatten if extracted inside a nested folder
  $found = Get-ChildItem -Path $uxDir -Recurse -Filter "uxplay.exe" -ErrorAction SilentlyContinue | Select-Object -First 1
  if (-not $found) {
    # Fallback via winget if available
    if (Get-Command winget -ErrorAction SilentlyContinue) {
      & winget install --id leapbtw.uxplay-windows --silent --accept-package-agreements --accept-source-agreements | Out-Null
    }
  }
  Write-Output "UXPLAY_OK"
}

function Extract-AppleMsiFromItunes {
  $itunesExe = Join-Path $tmp "iTunes64Setup.exe"
  $extractDir = Join-Path $tmp "itunes_extracted"
  New-Item -ItemType Directory -Force -Path $extractDir | Out-Null

  Invoke-WebRequest -Uri "https://www.apple.com/itunes/download/win64" -OutFile $itunesExe -TimeoutSec 180

  # Try tar (built-in Windows 10/11 bsdtar supports exe/cab/zip archives) or 7z
  $7z = Get-Command 7z -ErrorAction SilentlyContinue
  if (-not $7z -and (Test-Path "$env:ProgramFiles\7-Zip\7z.exe")) { $7z = "$env:ProgramFiles\7-Zip\7z.exe" }
  if ($7z) {
    & $7z x $itunesExe "-o$extractDir" -y | Out-Null
  } else {
    # Use PowerShell / tar fallback; if tar cannot extract PE, run /extract if supported
    & tar -xf $itunesExe -C $extractDir 2>$null
  }
  return $extractDir
}

function Install-AppleDriverDirect {
  $done = $false
  try {
    $dir = Extract-AppleMsiFromItunes
    $msi = Get-ChildItem -Path $dir -Recurse -Filter "AppleMobileDeviceSupport64.msi" -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($msi) {
      $p = Start-Process -FilePath "msiexec.exe" -ArgumentList "/i `"$($msi.FullName)`" /qn /norestart" -Verb RunAs -PassThru -Wait
      if ($p.ExitCode -eq 0 -or $p.ExitCode -eq 3010) { $done = $true }
    }
  } catch { }

  if (-not $done -and (Get-Command winget -ErrorAction SilentlyContinue)) {
    & winget install --id Apple.iTunes --silent --accept-package-agreements --accept-source-agreements | Out-Null
    if ($LASTEXITCODE -eq 0) { $done = $true }
  }
  if (-not $done) { throw "Could not install Apple driver automatically." }
  Write-Output "DRIVER_OK"
}

function Install-BonjourDirect {
  $done = $false
  try {
    $dir = Extract-AppleMsiFromItunes
    $msi = Get-ChildItem -Path $dir -Recurse -Filter "Bonjour64.msi" -ErrorAction SilentlyContinue | Select-Object -First 1
    if (-not $msi) {
      $msi = Get-ChildItem -Path $dir -Recurse -Filter "Bonjour.msi" -ErrorAction SilentlyContinue | Select-Object -First 1
    }
    if ($msi) {
      $p = Start-Process -FilePath "msiexec.exe" -ArgumentList "/i `"$($msi.FullName)`" /qn /norestart" -Verb RunAs -PassThru -Wait
      if ($p.ExitCode -eq 0 -or $p.ExitCode -eq 3010) { $done = $true }
    }
  } catch { }

  if (-not $done -and (Get-Command winget -ErrorAction SilentlyContinue)) {
    & winget install --id Apple.Bonjour --silent --accept-package-agreements --accept-source-agreements | Out-Null
    if ($LASTEXITCODE -eq 0) { $done = $true }
  }
  if (-not $done) { throw "Could not install Bonjour automatically." }
  Start-Service -Name "Bonjour Service" -ErrorAction SilentlyContinue
  Write-Output "BONJOUR_OK"
}

try {
  if ($Target -eq 'uxplay' -or $Target -eq 'all') { Install-UxPlay }
  if ($Target -eq 'driver' -or $Target -eq 'all') { Install-AppleDriverDirect }
  if ($Target -eq 'bonjour' -or $Target -eq 'all') { Install-BonjourDirect }
} finally {
  Remove-Item -Path $tmp -Recurse -Force -ErrorAction SilentlyContinue
}
