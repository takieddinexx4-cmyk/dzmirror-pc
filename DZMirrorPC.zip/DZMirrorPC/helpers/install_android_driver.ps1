param(
  [Parameter(Mandatory = $true)][string]$InstallRoot
)

$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$drvDir = Join-Path $InstallRoot "android_driver"
New-Item -ItemType Directory -Force -Path $drvDir | Out-Null
$zipPath = Join-Path $env:TEMP "google_usb_driver_$(Get-Random).zip"

try {
  Invoke-WebRequest -Uri "https://dl.google.com/android/repository/usb_driver_r13-windows.zip" -OutFile $zipPath -TimeoutSec 90
  Expand-Archive -Path $zipPath -DestinationPath $drvDir -Force
  $inf = Get-ChildItem -Path $drvDir -Recurse -Filter "android_winusb.inf" | Select-Object -First 1
  if (-not $inf) { throw "android_winusb.inf not found after extraction" }

  $p = Start-Process -FilePath "pnputil.exe" -ArgumentList "/add-driver `"$($inf.FullName)`" /install" -Verb RunAs -PassThru -Wait
  & pnputil.exe /scan-devices | Out-Null
  if ($p.ExitCode -ne 0 -and $p.ExitCode -ne 259) {
    throw "pnputil exited with code $($p.ExitCode)"
  }
  Write-Output "ANDROID_DRV_OK"
} finally {
  Remove-Item -Path $zipPath -Force -ErrorAction SilentlyContinue
}
