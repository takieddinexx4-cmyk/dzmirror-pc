param(
  [Parameter(Mandatory = $true)][string]$WindowTitle,
  [Parameter(Mandatory = $true)][string]$ConfigPath
)

$ErrorActionPreference = 'SilentlyContinue'

$csharp = @"
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Web.Script.Serialization;
using System.Windows.Forms;

public class DZKeymapEngine {
    [StructLayout(LayoutKind.Sequential)]
    public struct RECT { public int Left; public int Top; public int Right; public int Bottom; }

    [StructLayout(LayoutKind.Sequential)]
    public struct POINT { public int X; public int Y; }

    [StructLayout(LayoutKind.Sequential)]
    public struct INPUT {
        public uint type;
        public MOUSEINPUT mi;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct MOUSEINPUT {
        public int dx;
        public int dy;
        public uint mouseData;
        public uint dwFlags;
        public uint time;
        public IntPtr dwExtraInfo;
    }

    private const uint INPUT_MOUSE = 0;
    private const uint MOUSEEVENTF_MOVE = 0x0001;
    private const uint MOUSEEVENTF_LEFTDOWN = 0x0002;
    private const uint MOUSEEVENTF_LEFTUP = 0x0004;
    private const uint MOUSEEVENTF_ABSOLUTE = 0x8000;

    private const int WH_KEYBOARD_LL = 13;
    private const int WM_KEYDOWN = 0x0100;
    private const int WM_KEYUP = 0x0101;
    private const int WM_SYSKEYDOWN = 0x0104;
    private const int WM_SYSKEYUP = 0x0105;

    private delegate IntPtr LowLevelKeyboardProc(int nCode, IntPtr wParam, IntPtr lParam);

    [DllImport("user32.dll", SetLastError = true)]
    private static extern IntPtr SetWindowsHookEx(int idHook, LowLevelKeyboardProc lpfn, IntPtr hMod, uint dwThreadId);

    [DllImport("user32.dll", SetLastError = true)]
    private static extern bool UnhookWindowsHookEx(IntPtr hhk);

    [DllImport("user32.dll")]
    private static extern IntPtr CallNextHookEx(IntPtr hhk, int nCode, IntPtr wParam, IntPtr lParam);

    [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
    private static extern IntPtr GetModuleHandle(string lpModuleName);

    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    private static extern IntPtr FindWindow(string lpClassName, string lpWindowName);

    [DllImport("user32.dll")]
    private static extern IntPtr GetForegroundWindow();

    [DllImport("user32.dll")]
    private static extern bool GetClientRect(IntPtr hWnd, out RECT lpRect);

    [DllImport("user32.dll")]
    private static extern bool ClientToScreen(IntPtr hWnd, ref POINT lpPoint);

    [DllImport("user32.dll")]
    private static extern bool IsWindow(IntPtr hWnd);

    [DllImport("user32.dll")]
    private static extern bool IsIconic(IntPtr hWnd);

    [DllImport("user32.dll", SetLastError = true)]
    private static extern uint SendInput(uint nInputs, INPUT[] pInputs, int cbSize);

    [DllImport("user32.dll")]
    private static extern int GetSystemMetrics(int nIndex);

    private static IntPtr _hookId = IntPtr.Zero;
    private static LowLevelKeyboardProc _proc;
    private static string _targetTitle = "";
    private static string _configPath = "";
    private static DateTime _lastConfigWrite = DateTime.MinValue;
    private static IntPtr _targetHwnd = IntPtr.Zero;

    private static bool _enabled = true;
    private static bool _editMode = false;
    private static List<Dictionary<string, object>> _buttons = new List<Dictionary<string, object>>();
    private static HashSet<int> _pressedVks = new HashSet<int>();
    private static bool _joyActive = false;

    private static int _lastX = -1, _lastY = -1, _lastW = -1, _lastH = -1;
    private static bool _lastVisible = false;

    public static void Start(string title, string configPath) {
        _targetTitle = title;
        _configPath = configPath;
        LoadConfig();

        _proc = HookCallback;
        using (Process curProcess = Process.GetCurrentProcess())
        using (ProcessModule curModule = curProcess.MainModule) {
            _hookId = SetWindowsHookEx(WH_KEYBOARD_LL, _proc, GetModuleHandle(curModule.ModuleName), 0);
        }

        System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer();
        timer.Interval = 120;
        timer.Tick += (s, e) => {
            LoadConfig();
            TrackWindow();
        };
        timer.Start();

        Application.Run();
        if (_hookId != IntPtr.Zero) UnhookWindowsHookEx(_hookId);
    }

    private static void LoadConfig() {
        try {
            if (!File.Exists(_configPath)) return;
            DateTime wt = File.GetLastWriteTimeUtc(_configPath);
            if (wt == _lastConfigWrite) return;
            _lastConfigWrite = wt;
            string json = File.ReadAllText(_configPath, Encoding.UTF8);
            var ser = new JavaScriptSerializer();
            var obj = ser.Deserialize<Dictionary<string, object>>(json);
            if (obj == null) return;
            if (obj.ContainsKey("enabled")) _enabled = Convert.ToBoolean(obj["enabled"]);
            if (obj.ContainsKey("editMode")) _editMode = Convert.ToBoolean(obj["editMode"]);
            if (obj.ContainsKey("buttons") && obj["buttons"] is System.Collections.ArrayList arr) {
                var list = new List<Dictionary<string, object>>();
                foreach (var item in arr) {
                    if (item is Dictionary<string, object> d) list.Add(d);
                }
                _buttons = list;
            }
        } catch { }
    }

    private static void TrackWindow() {
        if (_targetHwnd == IntPtr.Zero || !IsWindow(_targetHwnd)) {
            _targetHwnd = FindWindow(null, _targetTitle);
        }
        if (_targetHwnd == IntPtr.Zero || !IsWindow(_targetHwnd) || IsIconic(_targetHwnd)) {
            if (_lastVisible) {
                _lastVisible = false;
                Console.WriteLine("BOUNDS:0,0,0,0,0");
                Console.Out.Flush();
            }
            return;
        }
        RECT rc;
        if (!GetClientRect(_targetHwnd, out rc)) return;
        POINT pt = new POINT { X = 0, Y = 0 };
        ClientToScreen(_targetHwnd, ref pt);
        int w = rc.Right - rc.Left;
        int h = rc.Bottom - rc.Top;
        if (w <= 10 || h <= 10) return;

        if (!_lastVisible || pt.X != _lastX || pt.Y != _lastY || w != _lastW || h != _lastH) {
            _lastVisible = true;
            _lastX = pt.X; _lastY = pt.Y; _lastW = w; _lastH = h;
            Console.WriteLine("BOUNDS:1," + pt.X + "," + pt.Y + "," + w + "," + h);
            Console.Out.Flush();
        }
    }

    private static int KeyNameToVk(string key) {
        if (string.IsNullOrEmpty(key)) return 0;
        key = key.Trim().ToUpperInvariant();
        if (key.Length == 1) {
            char c = key[0];
            if ((c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9')) return (int)c;
        }
        switch (key) {
            case "SPACE": return 0x20;
            case "ENTER": return 0x0D;
            case "TAB": return 0x09;
            case "ESC": case "ESCAPE": return 0x1B;
            case "SHIFT": case "LSHIFT": return 0xA0;
            case "RSHIFT": return 0xA1;
            case "CTRL": case "CONTROL": case "LCTRL": return 0xA2;
            case "ALT": case "LALT": return 0xA4;
            case "BACKSPACE": return 0x08;
            case "UP": case "ARROWUP": return 0x26;
            case "DOWN": case "ARROWDOWN": return 0x28;
            case "LEFT": case "ARROWLEFT": return 0x25;
            case "RIGHT": case "ARROWRIGHT": return 0x27;
            case "F1": return 0x70; case "F2": return 0x71; case "F3": return 0x72; case "F4": return 0x73;
            case "F5": return 0x74; case "F6": return 0x75; case "F7": return 0x76; case "F8": return 0x77;
            case "F9": return 0x78; case "F10": return 0x79; case "F11": return 0x7A; case "F12": return 0x7B;
            default: return 0;
        }
    }

    private static void SendMouse(int screenX, int screenY, uint flags) {
        int sw = GetSystemMetrics(0);
        int sh = GetSystemMetrics(1);
        if (sw <= 0 || sh <= 0) return;
        int absX = (int)Math.Round((double)screenX * 65535.0 / (sw - 1));
        int absY = (int)Math.Round((double)screenY * 65535.0 / (sh - 1));
        INPUT[] inp = new INPUT[1];
        inp[0].type = INPUT_MOUSE;
        inp[0].mi.dx = absX;
        inp[0].mi.dy = absY;
        inp[0].mi.dwFlags = MOUSEEVENTF_ABSOLUTE | MOUSEEVENTF_MOVE | flags;
        SendInput(1, inp, Marshal.SizeOf(typeof(INPUT)));
    }

    private static void HandleJoystick() {
        Dictionary<string, object> joy = null;
        foreach (var b in _buttons) {
            if (b.ContainsKey("type") && Convert.ToString(b["type"]) == "joystick") { joy = b; break; }
        }
        if (joy == null || !_lastVisible) return;

        int vkUp = KeyNameToVk(joy.ContainsKey("up") ? Convert.ToString(joy["up"]) : "W");
        int vkDown = KeyNameToVk(joy.ContainsKey("down") ? Convert.ToString(joy["down"]) : "S");
        int vkLeft = KeyNameToVk(joy.ContainsKey("left") ? Convert.ToString(joy["left"]) : "A");
        int vkRight = KeyNameToVk(joy.ContainsKey("right") ? Convert.ToString(joy["right"]) : "D");

        int dx = 0, dy = 0;
        if (_pressedVks.Contains(vkLeft)) dx -= 1;
        if (_pressedVks.Contains(vkRight)) dx += 1;
        if (_pressedVks.Contains(vkUp)) dy -= 1;
        if (_pressedVks.Contains(vkDown)) dy += 1;

        double cx = _lastX + (Convert.ToDouble(joy["x"]) / 100.0) * _lastW;
        double cy = _lastY + (Convert.ToDouble(joy["y"]) / 100.0) * _lastH;
        double radPct = joy.ContainsKey("radius") ? Convert.ToDouble(joy["radius"]) : 11.0;
        double rad = (radPct / 100.0) * Math.Min(_lastW, _lastH);

        if (dx == 0 && dy == 0) {
            if (_joyActive) {
                _joyActive = false;
                SendMouse((int)cx, (int)cy, MOUSEEVENTF_LEFTUP);
                Console.WriteLine("KEY:JOY:0");
                Console.Out.Flush();
            }
            return;
        }

        double len = Math.Sqrt(dx * dx + dy * dy);
        int tx = (int)Math.Round(cx + (dx / len) * rad);
        int ty = (int)Math.Round(cy + (dy / len) * rad);

        if (!_joyActive) {
            _joyActive = true;
            SendMouse((int)cx, (int)cy, MOUSEEVENTF_LEFTDOWN);
            Thread.Sleep(8);
        }
        SendMouse(tx, ty, 0);
        Console.WriteLine("KEY:JOY:1");
        Console.Out.Flush();
    }

    private static IntPtr HookCallback(int nCode, IntPtr wParam, IntPtr lParam) {
        if (nCode >= 0) {
            int msg = wParam.ToInt32();
            int vk = Marshal.ReadInt32(lParam);
            bool isDown = (msg == WM_KEYDOWN || msg == WM_SYSKEYDOWN);
            bool isUp = (msg == WM_KEYUP || msg == WM_SYSKEYUP);

            if (isDown && vk == 0x78) { // F9 toggles overlay visibility
                Console.WriteLine("TOGGLE_VIS");
                Console.Out.Flush();
            }

            if (_enabled && !_editMode && _lastVisible && _targetHwnd != IntPtr.Zero) {
                IntPtr fg = GetForegroundWindow();
                if (fg == _targetHwnd) {
                    // Check joystick keys
                    foreach (var b in _buttons) {
                        if (b.ContainsKey("type") && Convert.ToString(b["type"]) == "joystick") {
                            int u = KeyNameToVk(b.ContainsKey("up") ? Convert.ToString(b["up"]) : "W");
                            int d = KeyNameToVk(b.ContainsKey("down") ? Convert.ToString(b["down"]) : "S");
                            int l = KeyNameToVk(b.ContainsKey("left") ? Convert.ToString(b["left"]) : "A");
                            int r = KeyNameToVk(b.ContainsKey("right") ? Convert.ToString(b["right"]) : "D");
                            if (vk == u || vk == d || vk == l || vk == r) {
                                if (isDown) _pressedVks.Add(vk);
                                if (isUp) _pressedVks.Remove(vk);
                                HandleJoystick();
                                return (IntPtr)1;
                            }
                        }
                    }

                    // Check tap / hold buttons
                    foreach (var b in _buttons) {
                        if (b.ContainsKey("type") && Convert.ToString(b["type"]) == "joystick") continue;
                        int bvk = KeyNameToVk(b.ContainsKey("key") ? Convert.ToString(b["key"]) : "");
                        if (bvk == 0 || bvk != vk) continue;
                        string id = b.ContainsKey("id") ? Convert.ToString(b["id"]) : "";
                        int px = (int)Math.Round(_lastX + (Convert.ToDouble(b["x"]) / 100.0) * _lastW);
                        int py = (int)Math.Round(_lastY + (Convert.ToDouble(b["y"]) / 100.0) * _lastH);

                        if (isDown && !_pressedVks.Contains(vk)) {
                            _pressedVks.Add(vk);
                            SendMouse(px, py, MOUSEEVENTF_LEFTDOWN);
                            Console.WriteLine("KEY:" + id + ":1");
                            Console.Out.Flush();
                            return (IntPtr)1;
                        } else if (isUp && _pressedVks.Contains(vk)) {
                            _pressedVks.Remove(vk);
                            SendMouse(px, py, MOUSEEVENTF_LEFTUP);
                            Console.WriteLine("KEY:" + id + ":0");
                            Console.Out.Flush();
                            return (IntPtr)1;
                        } else if (isDown) {
                            return (IntPtr)1;
                        }
                    }
                }
            }
        }
        return CallNextHookEx(_hookId, nCode, wParam, lParam);
    }
}
"@

Add-Type -TypeDefinition $csharp -ReferencedAssemblies System.Windows.Forms, System.Web.Extensions
[DZKeymapEngine]::Start($WindowTitle, $ConfigPath)
