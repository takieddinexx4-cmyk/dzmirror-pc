'use strict';
const $ = (id) => document.getElementById(id);
const call = (...a) => window.api.call(...a);
const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

const SEG = {
  maxSize: ['الدقة', [['الأصلية', 0], ['2K', 2560], ['1080p', 1920], ['720p', 1280]]],
  fps: ['السلاسة (FPS)', [['30', 30], ['60', 60], ['90', 90], ['120', 120]]],
  bitrate: ['النقاء (Mbps)', [['8', 8], ['16', 16], ['24', 24], ['40', 40], ['64', 64]]],
  codec: ['الترميز', [['H.264 (متوافق)', 'h264'], ['H.265 (أنقى)', 'h265']]],
  mode: ['النمط', [['⚡ سرعة', 'fast'], ['💎 جودة', 'quality']]]
};
const TOG = [['audio', '🔊 بث الصوت'], ['awake', '☀️ إبقاء الهاتف مستيقظاً'], ['off', '🌙 إطفاء شاشة الهاتف أثناء البث'],
  ['touch', '👆 إظهار اللمسات'], ['top', '📌 النافذة فوق الكل'], ['view', '👁 عرض فقط (بدون تحكم)'], ['rec', '⏺ تسجيل الفيديو']];
const PRESETS = {
  game: { maxSize: 1280, fps: 60, bitrate: 16, codec: 'h264', mode: 'fast' },
  bal: { maxSize: 1920, fps: 60, bitrate: 24, codec: 'h264', mode: 'fast' },
  max: { maxSize: 0, fps: 60, bitrate: 64, codec: 'h264', mode: 'quality' }
};
let opts = Object.assign({ maxSize: 1920, fps: 60, bitrate: 24, codec: 'h264', mode: 'fast', audio: true, awake: true, off: false, touch: false, top: false, view: false, rec: false },
  JSON.parse(localStorage.getItem('dzopts') || '{}'));
let last = { devices: [], usb: [], active: [] };

function toast(m, ms = 3200) {
  const t = $('toast'); t.textContent = m; t.classList.add('show');
  clearTimeout(toast.h); toast.h = setTimeout(() => t.classList.remove('show'), ms);
}
function save() { localStorage.setItem('dzopts', JSON.stringify(opts)); }

function drawSettings() {
  $('segs').innerHTML = Object.entries(SEG).map(([k, [title, items]]) =>
    `<div class="seg"><label>${title}</label><div class="opts">${items.map(([t, v]) =>
      `<button data-k="${k}" data-v="${v}" class="${opts[k] === v ? 'on' : ''}">${t}</button>`).join('')}</div></div>`).join('');
  $('togs').innerHTML = TOG.map(([k, t]) =>
    `<div class="tog ${opts[k] ? 'on' : ''}" data-t="${k}"><span>${t}</span><span class="sw"></span></div>`).join('');
}
$('segs').addEventListener('click', (e) => {
  const b = e.target.closest('button'); if (!b) return;
  const k = b.dataset.k; const raw = b.dataset.v;
  opts[k] = typeof SEG[k][1][0][1] === 'number' ? Number(raw) : raw; save(); drawSettings();
});
$('togs').addEventListener('click', (e) => {
  const t = e.target.closest('.tog'); if (!t) return;
  opts[t.dataset.t] = !opts[t.dataset.t]; save(); drawSettings();
});
document.querySelector('.presets').addEventListener('click', (e) => {
  const b = e.target.closest('button'); if (!b) return;
  Object.assign(opts, PRESETS[b.dataset.p]); save(); drawSettings(); toast('تم تطبيق النمط');
});

function render(d) {
  last = d;
  const st = $('adbState');
  st.className = 'chip ok';
  st.innerHTML = `<i class="dot"></i>${d.devices.filter((x) => x.state === 'device').length} جهاز جاهز`;
  $('empty').style.display = d.devices.length || d.usb.some((u) => u.kind === 'ios') ? 'none' : 'block';

  const alerts = [];
  const androidUsb = d.usb.filter((u) => u.kind === 'android');
  const usbAdb = d.devices.filter((x) => !x.wifi);
  const unauth = d.devices.filter((x) => x.state === 'unauthorized');
  const off = d.devices.filter((x) => x.state === 'offline');
  if (androidUsb.length && !usbAdb.length) {
    const u = androidUsb[0];
    if (u.issue) alerts.push(`<div class="alert err">⚠️ تم اكتشاف هاتف <b>${esc(u.vendor)}</b> عبر USB لكن <b>التعريفات غير مثبتة</b>.<div class="acts"><button class="pri" data-a="fix">🛠 تثبيت التعريفات تلقائياً</button><button data-a="oem" data-v="${esc(u.vendor)}">🌐 تعريف ${esc(u.vendor)} الرسمي</button></div></div>`);
    else alerts.push(`<div class="alert">🔌 تم اكتشاف هاتف <b>${esc(u.vendor)}</b> عبر USB لكنه لم يظهر في البث.<br>فعّل <b>تصحيح USB</b> واختر وضع «نقل الملفات» ثم اقبل رسالة السماح على الهاتف.<div class="acts"><button data-a="help">كيف أفعّل تصحيح USB؟</button><button data-a="fix">🛠 إصلاح التعريفات</button><button data-a="restart">↻ إعادة تشغيل ADB</button></div></div>`);
  }
  unauth.forEach(() => alerts.push('<div class="alert">🔐 الهاتف متصل لكن <b>لم يوافق على الاتصال</b>. انظر لشاشة الهاتف واضغط «السماح دائماً» على رسالة تصحيح USB.</div>'));
  off.forEach(() => alerts.push('<div class="alert">⚠️ جهاز في حالة «غير متصل». افصل الكابل وأعد توصيله.<div class="acts"><button data-a="restart">↻ إعادة تشغيل ADB</button></div></div>'));
  $('alerts').innerHTML = alerts.join('');

  $('list').innerHTML = d.devices.filter((x) => x.state === 'device').map((x) => {
    const i = x.info || {}; const live = d.active.includes(x.serial);
    return `<div class="card"><div class="dev ${live ? 'live' : ''}"><div class="ic"></div><div class="meta">
      <div class="nm">${esc(i.name || x.serial)}</div>
      <div class="sub"><span class="tag ${x.wifi ? 'w' : ''}">${x.wifi ? '📶 واي فاي' : '🔌 USB'}</span>
        ${live ? '<span class="tag">● يبثّ الآن</span>' : ''}<br>
        الطراز: ${esc(i.model || '-')} • أندرويد ${esc(i.android)} • ${esc(i.size || '')}${i.battery ? ' • 🔋 ' + esc(i.battery) + '%' : ''}<br>
        <span dir="ltr">${esc(x.serial)}</span></div></div></div>
      <div class="acts">
        ${live ? `<button class="stop" data-a="stop" data-s="${esc(x.serial)}">⏹ إيقاف</button>` : `<button class="pri" data-a="start" data-s="${esc(x.serial)}">▶ ابدأ البث</button>`}
        <button data-a="shot" data-s="${esc(x.serial)}">📸 لقطة</button>
        ${x.wifi ? `<button data-a="disc" data-s="${esc(x.serial)}">⛔ فصل</button>` : `<button data-a="wifi" data-s="${esc(x.serial)}">📶 لاسلكي</button>`}
      </div></div>`;
  }).join('');

  const ios = d.usb.filter((u) => u.kind === 'ios');
  $('ios').innerHTML = ios.length ? `<div class="card"><h3>🍎 ${esc(ios[0].name || 'iPhone')} متصل</h3>
    <p class="muted">تعريفات Apple: ${d.appleDriver ? '✅ مثبتة' : '❌ غير مثبتة'}</p>
    <p class="muted">بث الآيفون يعمل عبر AirPlay داخل الواي فاي (بدون إنترنت). أندرويد فقط يدعم البث بالكابل.</p>
    <div class="acts">${d.appleDriver ? '' : '<button class="pri" data-a="apple">⬇ تثبيت تعريفات Apple</button>'}<button data-a="air">📡 بدء استقبال AirPlay</button></div></div>` : '';
}

document.addEventListener('click', async (e) => {
  const b = e.target.closest('button[data-a]'); if (!b) return;
  const a = b.dataset.a; const s = b.dataset.s;
  const dev = last.devices.find((x) => x.serial === s);
  const info = (dev && dev.info) || {};
  b.disabled = true;
  try {
    if (a === 'start') {
      const r = await call('stream:start', s, Object.assign({}, opts, { title: info.name, sdk: info.sdk || 0 }));
      toast(r.ok ? '▶ بدأ البث… ستظهر النافذة بعد لحظات' : '⚠️ ' + r.msg);
    } else if (a === 'stop') await call('stream:stop', s);
    else if (a === 'shot') {
      const r = await call('shot', s, info.name); toast(r.ok ? '📸 حُفظت اللقطة في مجلد الصور/DZMirror' : '⚠️ فشل أخذ اللقطة');
    } else if (a === 'wifi') {
      toast('جارٍ التحويل للاسلكي…', 6000);
      const r = await call('wifi:enable', s); toast(r.ok ? '✅ متصل لاسلكياً، يمكنك فصل الكابل الآن' : '⚠️ ' + (r.msg || 'فشل'), 5000);
    } else if (a === 'disc') await call('wifi:disconnect', s);
    else if (a === 'fix') { toast('وافق على نافذة المسؤول…', 6000); const r = await call('driver:fix'); toast(r.msg || '', 6000); }
    else if (a === 'oem') await call('oem:open', b.dataset.v);
    else if (a === 'restart') { await call('adb:restart'); toast('تمت إعادة تشغيل ADB'); }
    else if (a === 'apple') await call('apple:driver');
    else if (a === 'air') { const r = await call('apple:airplay'); toast(r.msg || '', 5000); }
    else if (a === 'help') showHelp();
  } finally { b.disabled = false; }
});

$('bConnect').onclick = async () => {
  const r = await call('wifi:connect', $('ip').value); toast(r.ok ? '✅ تم الاتصال' : '⚠️ ' + (r.msg || 'فشل الاتصال'), 4500);
};
$('bPair').onclick = async () => {
  const r = await call('wifi:pair', $('pairHost').value, $('pairCode').value); toast(r.ok ? '✅ تم الإقران، الآن اتصل بالعنوان الظاهر في شاشة التصحيح اللاسلكي' : '⚠️ ' + (r.msg || 'فشل'), 6000);
};
$('bShots').onclick = () => call('folder:open', 'pic');
$('bVids').onclick = () => call('folder:open', 'video');
$('bHelp').onclick = showHelp;
$('mx').onclick = () => $('modal').classList.add('hidden');
$('modal').onclick = (e) => { if (e.target.id === 'modal') $('modal').classList.add('hidden'); };

function showHelp() {
  $('mbody').innerHTML = `<h3>📱 أندرويد: تفعيل تصحيح USB</h3><ol>
    <li>الإعدادات ← حول الهاتف ← اضغط على «رقم الإصدار» 7 مرات.</li>
    <li>ارجع لـ الإعدادات ← خيارات المطور ← فعّل <b>تصحيح USB</b>.</li>
    <li>وصّل الكابل (استخدم كابل بيانات جيداً) واختر «نقل الملفات».</li>
    <li>اقبل رسالة «السماح بتصحيح USB» على الهاتف.</li></ol>
    <h3>📶 البث اللاسلكي</h3><p>بعد التوصيل بالكابل مرة، اضغط «لاسلكي» ثم افصل الكابل. الحاسوب والهاتف على نفس الواي فاي (أو نقطة اتصال). لا يُستهلك أي إنترنت.</p>
    <h3>🍎 آيفون</h3><p>يُكتشف الآيفون بالكابل وتُفحص تعريفات Apple. البث نفسه عبر AirPlay (واي فاي فقط). آبل لا تسمح ببث الشاشة عبر USB لويندوز مباشرة.</p>
    <h3>🎯 للحصول على أفضل أداء</h3><p>كابل USB 3 أو واي فاي 5GHz. جرّب نمط «⚡ سرعة» مع 60 إطاراً. للصورة الأنقى اختر «💎 أعلى جودة».</p>`;
  $('modal').classList.remove('hidden');
}

window.api.onEnded((d) => {
  if (d.code && d.msg) toast('⚠️ توقف البث: ' + d.msg, 7000);
  else if (d.code) toast('⚠️ توقف البث (رمز ' + d.code + ')', 5000);
});

async function tick() {
  try { render(await call('detect')); } catch (e) { $('adbState').innerHTML = '<i class="dot"></i>خطأ'; }
  setTimeout(tick, 2500);
}
drawSettings();
tick();
